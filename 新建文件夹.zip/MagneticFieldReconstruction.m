function uhBbar = MagneticFieldReconstruction(uh, Bxe, Bye)
%reconstruction magnetic field through Bxe Bye
%BDM projection on legendre basis
%(Bx,By)\in M^k = P^k(K)\bigoplus {\nabla\times (x^(k+1)y),\nabla\times (xy^(k+1))}
global kp
[Nx, Ny, ~, ~] = size(uh);
uhBbar = zeros(Nx, Ny, (kp + 2) * (kp + 1) / 2 + 2, 2);
if kp == 1
    %Bx = a0+a1 x+a2 y+ a3 (x^2 - 1/3) +a4 xy <- bx(y)
    %By = b0+b1 x+b2 y+ b3 xy +b4 (y^2 - 1/3) <- by(x)
    %
    %br0 - bl0 + bt0 - bb0 = 0

    br0 = Bxe(1 : end, 2 : end, 1);
    br1 = Bxe(1 : end, 2 : end, 2);

    bl0 = Bxe(1 : end, 1 : end - 1, 1);
    bl1 = Bxe(1 : end, 1 : end - 1, 2);

    bb0 = Bye(1 : end - 1, 1 : end, 1);
    bb1 = Bye(1 : end - 1, 1 : end, 2);

    bt0 = Bye(2 : end, 1 : end, 1);
    bt1 = Bye(2 : end, 1 : end, 2);

    %a1=-b2
    %b1
    uhBbar(:, :, 2, 1) = (br0 - bl0) / 2;
    uhBbar(:, :, 2, 2) = (bt1 + bb1) / 2;
    %uhBbar(i, j, 3, 2) = -uhBbar(i, j, 2, 1);

    %a2
    %b2=-a1
    uhBbar(:, :, 3, 1) = (br1 + bl1) / 2;
    uhBbar(:, :, 3, 2) = -uhBbar(:, :, 2, 1);%(bt0 - bb0) / 2;

    %b3=-2a3
    %a3
    uhBbar(:, :, 4, 1) = - (bt1 - bb1) / 4;
    uhBbar(:, :, 4, 2) = (bt1 - bb1) / 2;

    %a4=-2b4
    uhBbar(:, :, 5, 1) = (br1 - bl1) / 2;
    uhBbar(:, :, 5, 2) = - (br1 - bl1) / 4;

    %a0 b0
    uhBbar(:, :, 1, 1) = (br0 + bl0) / 2 - 2 / 3 * uhBbar(:, :, 4, 1);
    uhBbar(:, :, 1, 2) = (bt0 + bb0) / 2 - 2 / 3 * uhBbar(:, :, 5, 2);
   
end

if kp == 2
    %Bx = a0 + a1 x + a2 y + a3 (x^2 - 1/3) + a4 xy + a5 (y^2 - 1/3) + a6 x^3 - 3/5x + a7 xy^2  <- bx(y)
    %By = b0 + b1 x + b2 y + b3 (x^2 - 1/3) + b4 xy + b5 (y^2 - 1/3) + b6 x^2y + b7 y^3 - 3/5y  <- by(x)
    %
    %br1-bl1+1/3(br2-bl2)+bt1-bb+1/3(bt2-bb2)=0

    %x is constant
    %a+-
    br0 = Bxe(:, 2 : end, 1);
    br1 = Bxe(:, 2 : end, 2);
    br2 = Bxe(:, 2 : end, 3);

    bl0 = Bxe(:, 1 : end - 1, 1);
    bl1 = Bxe(:, 1 : end - 1, 2);
    bl2 = Bxe(:, 1 : end - 1, 3);

    %y is constant
    %b+-
    bb0 = Bye(1 : end - 1, :, 1);
    bb1 = Bye(1 : end - 1, :, 2);
    bb2 = Bye(1 : end - 1, :, 3);

    bt0 = Bye(2 : end, :, 1);
    bt1 = Bye(2 : end, :, 2);
    bt2 = Bye(2 : end, :, 3);

    %coefficient \tilde{a0}^{\pm} \tilde{b0}^{\pm} under 1, x, y, x^2, xy, y^2 ... basis
    br00 = br0 - 1 / 3 * br2;
    bl00 = bl0 - 1 / 3 * bl2;

    bt00 = bt0 - 1 / 3 * bt2;
    bb00 = bb0 - 1 / 3 * bb2;

    %under 1, x, y, x^2, xy, y^2 ... basis
    %b1
    uhBbar(:, :, 2, 2) = (bt1 + bb1) / 2;
    %a2
    uhBbar(:, :, 3, 1) = (br1 + bl1) / 2;
    %b4 a3
    uhBbar(:, :, 4, 1) = - (bt1 - bb1) / 4;
    uhBbar(:, :, 5, 2) = (bt1 - bb1) / 2;
    %b3
    uhBbar(:, :, 4, 2) = (bt2 + bb2) / 2;
    %a4 b5
    uhBbar(:, :, 5, 1) = (br1 - bl1) / 2;
    uhBbar(:, :, 6, 2) = - (br1 - bl1) / 4;
    %a5
    uhBbar(:, :, 6, 1) = (br2 + bl2) / 2;
    %a7 b7
    uhBbar(:, :, 8, 1) = (br2 - bl2) / 2;
    uhBbar(:, :, 8, 2) = - (br2 - bl2) / 6;
    %a0
    uhBbar(:, :, 1, 1) = (br00 + bl00) / 2 - uhBbar(:, :, 4, 1);
    %b6 a6
    uhBbar(:, :, 7, 2) = (bt2 - bb2) / 2;
    uhBbar(:, :, 7, 1) = - (bt2 - bb2) / 6;
    %b0
    uhBbar(:, :, 1, 2) = (bt00 + bb00) / 2 - uhBbar(:, :, 6, 2);
    %a1 b2
    uhBbar(:, :, 2, 1) = (br00 - bl00) / 2 - uhBbar(:, :, 7, 1);
    uhBbar(:, :, 3, 2) = -uhBbar(:, :, 2, 1);

    %under legendre basis
    uhBbar(:, :, 1, 1) = uhBbar(:, :, 1, 1) + 1 / 3 * uhBbar(:, :, 4, 1) + 1 / 3 * uhBbar(:, :, 6, 1);
    uhBbar(:, :, 2, 1) = uhBbar(:, :, 2, 1) + 3 / 5 * uhBbar(:, :, 7, 1) + 1 / 3 * uhBbar(:, :, 8, 1);

    uhBbar(:, :, 1, 2) = uhBbar(:, :, 1, 2) + 1 / 3 * uhBbar(:, :, 4, 2) + 1 / 3 * uhBbar(:, :, 6, 2);
    uhBbar(:, :, 3, 2) = uhBbar(:, :, 3, 2) + 1 / 3 * uhBbar(:, :, 7, 2) + 3 / 5 * uhBbar(:, :, 8, 2);

end

end

