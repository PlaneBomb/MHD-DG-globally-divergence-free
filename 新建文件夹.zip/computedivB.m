function divB = computedivB(uhB, Bxe, Bye)
global point weight hh
[Nx, Ny, dim1, dim2] = size(uhB);
%uhGB = ValueGausspointB(uhB);
[uhGBdx, uhGBdy] = DerivateValueGausspointB(uhB);
%
%compute \partial_x Bx jump on vertical edges
%compute \partial_y By jump on horizontal edges
%[uhGBdxjmp,uhGBdyjmp] = 
%
divB = 0;
for i = 1 : Nx
    for j = 1 : Ny
        for p = 1 : 4
            for q = 1 : 4
                divB = divB + weight(p) * weight(q) * (uhGBdx(i, j, p, q, 1) + uhGBdy(i, j, p, q, 2)) ^ 2 * hh ^ 2;
            end 
        end
    end
end
disp(['divB = ' num2str(sqrt(divB))]);
end

