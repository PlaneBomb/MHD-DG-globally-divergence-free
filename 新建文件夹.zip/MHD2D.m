%MHD2D.m we achieve globally divergence free
%
global point weight phi phix phiy hh m1 m phiB phiL phiR phiU phiD phi1d phi1dx phiBD phiBU phiBL phiBR phil1d phir1d
global bc prob limiterind kp

GaussQuadratureset;
%%

bc='period';
%%
%limiter = 0 no limiter
%limiter = 1 TVD limiter
%limiter = 2 TVB limiter
limiterind = 0;
%%
%prob = 1 smoothvortex
%prob = 2 smoothscalar
%prob = 3 orszagtangvortex
prob = 4;
%initial condition
switch prob
    case 1
        smoothvortex;
    case 2
        smoothscalar;
    case 3
        % Orszag-Tang Vortex
        orszagtangvortex;
    case 4
        smoothalfvenwave;
    case 5
        constantvelocity;
end
%%
%polynomial degree
kp = 2;
%%
tFinal = 2;
N = 256;


if  kp == 1
    CFL = 0.3;
else
    CFL = 0.18;
end

tic

%mesh
h = (xb - xa) / N;
hh = h / 2;

% phix=phix/hh;
% phiy=phiy/hh;

xc = linspace(xa, xb, N + 1);
yc = linspace(ya, yb, N + 1);


xmid = (xc(1 : end - 1) + xc(2 : end)) / 2;
ymid = (yc(1 : end - 1) + yc(2 : end)) / 2;
%elements' center coordinates
[Xmid,Ymid] = meshgrid(xmid, ymid);
%edges coordinates
[Xc_vertical, Yc_vertical] = meshgrid(xc, ymid);
[Xc_horizon, Yc_horizon] = meshgrid(xmid, yc);

uinit = zeros(N, N, 4, 4, 6);
uinitB = zeros(N, N, 4, 4, 2);

%initial value on gauss point in elements
for i = 1 : N
    for j = 1 : N
        pointx=hh*point+Xmid(i,j);
        pointy=hh*point+Ymid(i,j);
        for p=1:4
            for q=1:4
                uinit(i,j,p,q,1)=f1(pointx(p),pointy(q));
                uinit(i,j,p,q,2)=f2(pointx(p),pointy(q));
                uinit(i,j,p,q,3)=f3(pointx(p),pointy(q));
                uinit(i,j,p,q,4)=f4(pointx(p),pointy(q));

                uinit(i,j,p,q,5)=f5(pointx(p),pointy(q));
                uinit(i,j,p,q,6)=f6(pointx(p),pointy(q));

                uinitB(i,j,p,q,1)=f7(pointx(p),pointy(q));
                uinitB(i,j,p,q,2)=f8(pointx(p),pointy(q));
            end
        end
    end
end

%initial coefficient
uh = zeros(N, N, (kp + 2) * (kp + 1) / 2, 6);
uhB = zeros(N, N, (kp + 2) * (kp + 1) / 2, 2);


for k = 1 : (kp + 2) * (kp + 1) / 2
    for p = 1 : 4
        for q = 1 : 4
            uh(:, :, k, :) = uh(:, :, k, :) + weight(p) * weight(q) * reshape(uinit(:, :, p, q, :), [N, N, 1, 6]) ...
                .* phi(p, q, k);
            uhB(:, :, k, :) = uhB(:, :, k, :) + weight(p) * weight(q) * reshape(uinitB(:, :, p, q, :), [N, N, 1, 2]) ...
                .* phi(p, q, k);
        end
    end
end

for k = 1 : (kp + 2) * (kp + 1) / 2
    uh(:, :, k, :) = uh(:, :, k, :) / m(k);
    uhB(:, :, k, :) = uhB(:, :, k, :) / m(k);
end

%%
%initial magnetic field on edges

% Bxe = zeros(N + 1, N, kp + 1);
% Bye = zeros(N, N + 1, kp + 1);
Bxesize = size(Xc_vertical);
Byesize = size(Xc_horizon);
Bxe = zeros([Bxesize, kp + 1]);
Bye = zeros([Byesize, kp + 1]);
%Bxe means edges whose x coordinate is constant,that is vertical  Bx(x_{i+1/2},y)
f = f7;
for i = 1 : Bxesize(1)
    for j = 1 : Bxesize(2)
        xx = Xc_vertical(i, j);
        yy = Yc_vertical(i, j);
        for p = 1 : 4
            Bxe(i, j, :) = Bxe(i, j, :) + weight(p) * f(xx, yy + hh * point(p)) ...
                * reshape(phi1d(p, 1 : kp + 1),[1, 1, kp + 1]);
        end
    end
end
for  k = 1 : kp + 1
    Bxe(:, :, k) = Bxe(:, :, k) / m1(k);
end


%Bye means edges whose y coordinates are constant,that is horizontal,By(x,y_{j+1/2})

f = f8;
for i = 1 : Byesize(1)
    for j = 1 : Byesize(2)
        xx = Xc_horizon(i, j);
        yy = Yc_horizon(i, j);
        for p = 1 : 4
            Bye(i, j, :) = Bye(i, j, :) + weight(p) * f(xx + hh * point(p), yy) ...
                * reshape(phi1d(p, 1 : kp + 1), [1, 1, kp + 1]);
        end
    end
end
for  k = 1 : kp + 1
    Bye(:, :, k) = Bye(:, :, k) / m1(k);
end


uhB = MagneticFieldReconstruction(uh, Bxe, Bye);

%
t=0;
% uh = load('uh21922.mat');
% uhB = load('uhB21922.mat');
% Bxe = load('Bxe21922.mat');
% Bye = load('Bye21922.mat');
% t = load('t22.mat');
% 
% uh = struct2array(uh);
% uhB = struct2array(uhB);
% Bxe = struct2array(Bxe);
% Bye = struct2array(Bye);
% t = struct2array(t);
while t < tFinal
    uhG = ValueGausspoint(uh);
    uhGB = ValueGausspointB(uhB);

    [alphax, alphay] = Alpha(uhG, uhGB, N, 4);
    alphaxx = max(max(alphax));
    alphayy = max(max(alphay));
    dt = CFL / (alphaxx / h + alphayy / h);

    if t + dt >= tFinal
        dt = tFinal - t;
        t = tFinal;
    else
        t = t + dt;
    end

    %RK3 for U & B
    du = Lh(uh, uhB, Bxe, Bye);
    [dBxe, dBye] = LhB(uh, uhB, Bxe, Bye);
    uh1 = uh + dt * du;
    uh1 = Limiter(uh1);
    Bxe1 = Bxe + dt * dBxe;
    Bye1 = Bye + dt * dBye;
    uhB1 = MagneticFieldReconstruction(uh1, Bxe1, Bye1);


    du = Lh(uh1, uhB1, Bxe1, Bye1);
    [dBxe, dBye] = LhB(uh1, uhB1, Bxe1, Bye1);
    uh2 = 3 / 4 * uh + 1 / 4 * uh1 + 1 / 4 * dt * du;
    uh2 = Limiter(uh2);
    Bxe2 = 3 / 4 * Bxe + 1 / 4 * Bxe1 + 1 / 4 * dt * dBxe;
    Bye2 = 3 / 4 * Bye + 1 / 4 * Bye1 + 1 / 4 * dt * dBye;
    uhB2 = MagneticFieldReconstruction(uh2, Bxe2, Bye2);


    du = Lh(uh2, uhB2, Bxe2, Bye2);
    [dBxe, dBye] = LhB(uh2, uhB2, Bxe2, Bye2);
    uh = 1 / 3 * uh + 2 / 3 * uh2 + 2 / 3 * dt * du;
    uh = Limiter(uh);
    Bxe = 1 / 3 * Bxe + 2 / 3 * Bxe2 + 2 / 3 * dt * dBxe;
    Bye = 1 / 3 * Bye + 2 / 3 * Bye2 + 2 / 3 * dt * dBye;
    uhB = MagneticFieldReconstruction(uh, Bxe, Bye);
    if prob == 3
        hold on
        if kp == 1
            uref = uh(:, :, 1, 1);
        elseif kp == 2
            uref = uh(:, :, 1, 1) - 1 / 3 * uh(:, :, 4, 1) - 1 / 3 * uh(:, :, 6, 1);
        end

        %

        contour(Xmid, Ymid, uref, 20);
        %mesh(Xmid,Ymid,uref);
        xlabel('x');
        ylabel(num2str(t), Rotation = - pi / 2);
        pause(0.0001)
        clf
        if kp == 1
            if  t>=1 && t-1<0.002  && prob == 3
                save("uh11921.mat","uh");
                save("uhB11921.mat","uhB");
                save("Bxe11921.mat","Bxe");
                save("Bye11921.mat","Bye");
                save("t1.mat","t");
            end
            if  t>=2 && t-2<0.002  && prob == 3
                save("uh11922.mat","uh");
                save("uhB11922.mat","uhB");
                save("Bxe11922.mat","Bxe");
                save("Bye11922.mat","Bye");
                save("t2.mat","t");
            end
            if  t>=3 && t-3<0.002  && prob == 3
                save("uh11923.mat","uh");
                save("uhB11923.mat","uhB");
                save("Bxe11923.mat","Bxe");
                save("Bye11923.mat","Bye");
                save("t3.mat","t");
            end
            if  t>=4 && t-4<0.002  && prob == 3
                save("uh11924.mat","uh");
                save("uhB11924.mat","uhB");
                save("Bxe11924.mat","Bxe");
                save("Bye11924.mat","Bye");
                save("t4.mat","t");
            end
        end

        if kp == 2
            if  t>=1 && t-1<0.002  && prob == 3
                save("uh21921.mat","uh");
                save("uhB21921.mat","uhB");
                save("Bxe21921.mat","Bxe");
                save("Bye21921.mat","Bye");
                save("t21.mat","t");
            end
            if  t>=2 && t-2<0.002  && prob == 3
                save("uh21922.mat","uh");
                save("uhB21922.mat","uhB");
                save("Bxe21922.mat","Bxe");
                save("Bye21922.mat","Bye");
                save("t22.mat","t");
            end
            if  t>=3 && t-3<0.002  && prob == 3
                save("uh21923.mat","uh");
                save("uhB21923.mat","uhB");
                save("Bxe21923.mat","Bxe");
                save("Bye21923.mat","Bye");
                save("t23.mat","t");
            end
            if  t>=4 && t-4<0.002  && prob == 3
                save("uh21924.mat","uh");
                save("uhB21924.mat","uhB");
                save("Bxe21924.mat","Bxe");
                save("Bye21924.mat","Bye");
                save("t24.mat","t");
            end
        end
    end
end



%reference solution
if kp==2
    uref=uh(:,:,1,1)-1/3*uh(:,:,4,1)-1/3*uh(:,:,6,1);
else
    uref=uh(:,:,1,1);
end

% uref=f7(Xmid,Ymid);
mesh(Xmid,Ymid,uref);
hold on
% Bxeref = Bxe(:,:,1);
% [xt,yt]=meshgrid(xc,ymid);
% mesh(xt,yt,Bxeref);
% xlabel('x');
% ylabel(num2str(t),Rotation=-pi/2);
toc
densityerr;
rhouxerr;
uxerr;
uzerr;
pressureerr;
Eerr
Bxerr;

%Bxeerr;
%Byeerr;
%computedivB(uhB,Bxe,Bye);
%checkdivB(Bhar);

