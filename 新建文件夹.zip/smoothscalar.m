gamma = 5 / 3;

p = @(x, y) 5;
v1 = @(x, y) 1;
v2 = @(x, y) 1;
v3 = @(x, y) 0;

%rho
f1 = @(x, y) 2 + sin(x + y);
%rhoux
f2 = @(x, y) f1(x, y) .* v1(x, y);
%rhouy
f3 = @(x, y) f1(x, y) .* v2(x, y);
%rhouz
f4 = @(x, y) f1(x, y) .* v3(x, y);
%magnetic field
%bz
f5 = @(x, y) 0;

%bx by
f7 = @(x, y) 0;
f8 = @(x, y) 0;

%energy
f6 = @(x, y) p(x, y) / (gamma - 1) + 0.5 * (f2(x, y) .^ 2 + f3(x, y) .^ 2 + f4(x, y) .^ 2) ./ f1(x, y) + 0.5*(f5(x,y).^2 + f7(x,y).^2+f8(x,y).^2);
xa = 0; xb = 2 * pi;
ya = 0; yb = 2 * pi;