function [Bx, By] = ValueGausspointBedge(uhB)
%magnetic field on each edge's gauss points
%Bx,By N * N * 4 * 4    4 points at TOP, BOTTOM, LEFT, RIGHT
global kp phiU phiD phiL phiR phiBU phiBD phiBL phiBR
[Nx, Ny, dimB, ~] = size(uhB);
Bx = zeros(Nx, Ny, 4, 4); 
By = zeros(Nx, Ny, 4, 4);
Bx1 = zeros(Nx ,Ny, 4, 4);
By1 = zeros(Nx, Ny, 4, 4);
if  kp == 1
    %Bx = a0+a1 x+a2 y+ a3 (x^2 - 1/3) +a4 xy <- bx(y)

    %top y = 1
    %Bx = a0 + a2 + (a1+a4)x+a3(x^2-1/3);
    uhBxtop = zeros(Nx, Ny, 3);
    uhBxtop(:, :, 1) = uhB(:, :, 1, 1) + uhB(:, :, 3, 1);
    uhBxtop(:, :, 2) = uhB(:, :, 2, 1) + uhB(:, :, 5, 1);
    uhBxtop(:, :, 3) = uhB(:, :, 4, 1);
    uhBxt = ValueGausspoint1D(uhBxtop);
    Bx1(:, :, :, 1) = reshape(uhBxt, [Nx, Ny, 4, 1]);

    %bottom y = -1
    uhBxbottom = zeros(Nx, Ny, 3);
    uhBxbottom(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 3, 1);
    uhBxbottom(:, :, 2) = uhB(:, :, 2, 1) - uhB(:, :, 5, 1);
    uhBxbottom(:, :, 3) = uhB(:, :, 4, 1);
    uhBxb = ValueGausspoint1D(uhBxbottom);
    Bx1(:, :, :, 2) = reshape(uhBxb, [Nx, Ny, 4, 1]);

    %left x = -1
    uhBxleft = zeros(Nx, Ny, 2);
    uhBxleft(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1);
    uhBxleft(:, :, 2) = uhB(:, :, 3, 1) - uhB(:, :, 5, 1);
    uhBxl = ValueGausspoint1D(uhBxleft);
    Bx1(:, :, :, 3) = reshape(uhBxl, [Nx, Ny, 4, 1]);

    %right x = 1
    uhBxright = zeros(Nx, Ny, 2);
    uhBxright(:, :, 1) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1);
    uhBxright(:, :, 2) = uhB(:, :, 3, 1) + uhB(:, :, 5, 1);
    uhBxr = ValueGausspoint1D(uhBxright);
    Bx1(:, :, :, 4) = reshape(uhBxr, [Nx, Ny, 4, 1]);

    %By = b0+b1 x+b2 y+ b3 xy +b4 (y^2 - 1/3)
    %top y = 1
    uhBytop = zeros(Nx, Ny, 2);
    uhBytop(:, :, 1) = uhB(:, :, 1, 2) + uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 5, 2);
    uhBytop(:, :, 2) = uhB(:, :, 2, 2) + uhB(:, :, 4, 2);
    uhByt = ValueGausspoint1D(uhBytop);
    By1(:, :, :, 1) = reshape(uhByt, [Nx, Ny, 4, 1]);

    %bottom y = -1
    uhBybottom = zeros(Nx, Ny, 2);
    uhBybottom(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 5, 2);
    uhBybottom(:, :, 2) = uhB(:, :, 2, 2) - uhB(:, :, 4, 2);
    uhByb = ValueGausspoint1D(uhBybottom);
    By1(:, :, :, 2) = reshape(uhByb, [Nx, Ny, 4, 1]);

    %left x = -1
    uhByleft = zeros(Nx, Ny, 3);
    uhByleft(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2);
    uhByleft(:, :, 2) = uhB(:, :, 3, 2) - uhB(:, :, 4, 2);
    uhByleft(:, :, 3) = uhB(:, :, 5, 2);
    uhByl = ValueGausspoint1D(uhByleft);
    By1(:, :, :, 3) = reshape(uhByl, [Nx, Ny, 4, 1]);

    uhByright = zeros(Nx, Ny, 3);
    uhByright(:, :, 1) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2);
    uhByright(:, :, 2) = uhB(:, :, 3, 2) + uhB(:, :, 4, 2);
    uhByright(:, :, 3) = uhB(:, :, 5, 2);
    uhByr = ValueGausspoint1D(uhByright);
    By1(:, :, :, 4) = reshape(uhByr, [Nx, Ny, 4, 1]);


end
if kp == 2
    %Bx = a0 + a1 x + a2 y + a3 (x^2 - 1/3) + a4 xy + a5 (y^2 - 1/3) + a6 x^3 - 3/5x + a7 x(y^2-1/3)  <- bx(y)

    %y = 1
    uhBxtop = zeros(Nx, Ny, 4);
    uhBxtop(:, :, 1) = uhB(:, :, 1, 1) + uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 6, 1);
    uhBxtop(:, :, 2) = uhB(:, :, 2, 1) + uhB(:, :, 5, 1) + 2 / 3 * uhB(:, :, 8, 1);%这里之前系数没加2/3，错了
    uhBxtop(:, :, 3) = uhB(:, :, 4, 1);

    uhBxtop(:, :, 4) = uhB(:, :, 7, 1);
    uhBxt = ValueGausspoint1D(uhBxtop);
    Bx1(:, :, :, 1) = reshape(uhBxt, [Nx, Ny, 4, 1]);


    uhBxbottom = zeros(Nx, Ny, 4);
    uhBxbottom(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 6, 1);
    uhBxbottom(:, :, 2) = uhB(:, :, 2, 1) - uhB(:, :, 5, 1) + 2 / 3 * uhB(:, :, 8, 1);
    uhBxbottom(:, :, 3) = uhB(:, :, 4, 1);
    uhBxbottom(:, :, 4) = uhB(:, :, 7, 1);
    uhBxb = ValueGausspoint1D(uhBxbottom);
    Bx1(:, :, :, 2) = reshape(uhBxb, [Nx, Ny, 4, 1]);
    %x = -1
    uhBxleft = zeros(Nx, Ny, 3);
    uhBxleft(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1) - 2 / 5 * uhB(:, :, 7, 1);
    uhBxleft(:, :, 2) = uhB(:, :, 3, 1) - uhB(:, :, 5, 1);
    uhBxleft(:, :, 2) = uhB(:, :, 6, 1) - uhB(:, :, 8, 1);
    uhBxl = ValueGausspoint1D(uhBxleft);
    Bx1(:, :, :, 3) = reshape(uhBxl, [Nx, Ny, 4, 1]);

    uhBxright = zeros(Nx, Ny, 3);
    uhBxright(:, :, 1) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1) + 2 / 5 * uhB(:, :, 7, 1);
    uhBxright(:, :, 2) = uhB(:, :, 3, 1) + uhB(:, :, 5, 1);
    uhBxright(:, :, 3) = uhB(:, :, 6, 1) + uhB(:, :, 8, 1);
    uhBxr = ValueGausspoint1D(uhBxright);
    Bx1(:, :, :, 4) = reshape(uhBxr, [Nx, Ny, 4, 1]);

    %By = b0 + b1 x + b2 y + b3 (x^2 - 1/3) + b4 xy + b5 (y^2 - 1/3) + b6 (x^2-1/3)y + b7 y^3 - 3/5y  <- by(x)
    %By
    uhBytop = zeros(Nx, Ny, 3);
    uhBytop(:, :, 1) = uhB(:, :, 1, 2) + uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 6, 2) + 2 / 5 * uhB(:, :, 8, 2);
    uhBytop(:, :, 2) = uhB(:, :, 2, 2) + uhB(:, :, 5, 2);
    uhBytop(:, :, 3) = uhB(:, :, 4, 2) + uhB(:, :, 7, 2);
    uhByt = ValueGausspoint1D(uhBytop);
    By1(:, :, :, 1) = reshape(uhByt, [Nx, Ny, 4, 1]);

    uhBybottom = zeros(Nx, Ny, 3);
    uhBybottom(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 6, 2) - 2 / 5 * uhB(:, :, 8, 2);
    uhBybottom(:, :, 2) = uhB(:, :, 2, 2) - uhB(:, :, 5, 2);
    uhBybottom(:, :, 3) = uhB(:, :, 4, 2) - uhB(:, :, 7, 2);
    uhByb = ValueGausspoint1D(uhBybottom);
    By1(:, :, :, 2) = reshape(uhByb, [Nx, Ny, 4, 1]);

    uhByleft = zeros(Nx, Ny, 4);
    uhByleft(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2) + 2 / 3 * uhB(:, :, 4, 2);
    uhByleft(:, :, 2) = uhB(:, :, 3, 2) - uhB(:, :, 5, 2) + 2 / 3 * uhB(:, :, 7, 2);
    uhByleft(:, :, 3) = uhB(:, :, 6, 2);
    uhByleft(:, :, 4) = uhB(:, :, 8, 2);
    uhByl = ValueGausspoint1D(uhByleft);
    By1(:, :, :, 3) = reshape(uhByl, [Nx, Ny, 4, 1]);

    uhByright = zeros(Nx, Ny, 4);
    uhByright(:, :, 1) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2) + 2 / 3 * uhB(:, :, 4, 2);
    uhByright(:, :, 2) = uhB(:, :, 3, 2) + uhB(:, :, 5, 2) + 2 / 3 * uhB(:, :, 7, 2);
    uhByright(:, :, 3) = uhB(:, :, 6, 2);
    uhByright(:, :, 3) = uhB(:, :, 8, 2);
    uhByr = ValueGausspoint1D(uhByright);
    By1(:, :, :, 4) = reshape(uhByr, [Nx, Ny, 4, 1]);


end
%用下面的就对了,那上面为什么错了呢valuegausspoint1d里矢量化搞错了
if kp == 1
    %LU
    phiBxD = phiD(:, 1 : 5);
    phiByD = phiD(:, [1 : 3, 5 : 6]);

    phiBxU = phiU(:, 1 : 5);
    phiByU = phiU(:, [1 : 3, 5 : 6]);

    phiBxL = phiL(:, 1 : 5);
    phiByL = phiL(:, [1 : 3, 5 : 6]);

    phiBxR = phiR(:, 1 : 5);
    phiByR = phiR(:, [1 : 3, 5 : 6]);
else
    %LU
    phiBxD = [phiD(:, :), phiBD(:, 1 : 2)];
    phiByD = [phiD(:, :), phiBD(:, 3 : 4)];
    phiBxU = [phiU(:, :), phiBU(:, 1 : 2)];
    phiByU = [phiU(:, :), phiBU(:, 3 : 4)];

    phiBxL = [phiL(:, :), phiBL(:, 1 : 2)];
    phiByL = [phiL(:, :), phiBL(:, 3 : 4)];
    phiBxR = [phiR(:, :), phiBR(:, 1 : 2)];
    phiByR = [phiR(:, :), phiBR(:, 3 : 4)];
end


    
Bx(:, :, :, 1) = reshape(reshape(uhB(:, :, :, 1), [Nx * Ny, dimB]) * phiBxU(:, :)',[Nx, Ny, 4]);
Bx(:, :, :, 2) = reshape(reshape(uhB(:, :, :, 1), [Nx * Ny, dimB]) * phiBxD(:, :)',[Nx, Ny, 4]);
Bx(:, :, :, 3) = reshape(reshape(uhB(:, :, :, 1), [Nx * Ny, dimB]) * phiBxL(:, :)',[Nx, Ny, 4]);
Bx(:, :, :, 4) = reshape(reshape(uhB(:, :, :, 1), [Nx * Ny, dimB]) * phiBxR(:, :)',[Nx, Ny, 4]);

By(:, :, :, 1) = reshape(reshape(uhB(:, :, :, 2), [Nx * Ny, dimB]) * phiByU(:, :)',[Nx, Ny, 4]);
By(:, :, :, 2) = reshape(reshape(uhB(:, :, :, 2), [Nx * Ny, dimB]) * phiByD(:, :)',[Nx, Ny, 4]);
By(:, :, :, 3) = reshape(reshape(uhB(:, :, :, 2), [Nx * Ny, dimB]) * phiByL(:, :)',[Nx, Ny, 4]);
By(:, :, :, 4) = reshape(reshape(uhB(:, :, :, 2), [Nx * Ny, dimB]) * phiByR(:, :)',[Nx, Ny, 4]);

% 
% Bx = Bx1;
% By = By1;
end
