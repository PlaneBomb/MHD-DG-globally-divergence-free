function du = Lh(uh, uhB, Bxe, Bye)
global  weight phiD phiU phiL phiR phix phiy hh m
global bc kp
%GaussQuadratureset;
%%
% period BC
[N, ~, dim1, dim2] = size(uh);
[~, ~, dimB1, dimB2] = size(uhB);

uhh = zeros(N + 2, N + 2, dim1, dim2);
uhhB = zeros(N + 2, N + 2, dimB1, dimB2);

du = zeros(size(uh));
if strcmp(bc, 'period')
    uhh(2 : end - 1, 2 : end - 1, :, :) = uh;
    uhhB(2 : end - 1, 2 : end - 1, :, :) = uhB;

    uhh([1, end], 2 : end - 1, :, :) = uh([end, 1], :, :, :);
    uhh(2 : end - 1, [1, end], :, :) = uh(:, [end, 1], :, :);

    uhhB([1, end], 2 : end - 1, :, :) = uhB([end, 1], :, :, :);
    uhhB(2 : end - 1, [1, end], :, :) = uhB(:, [end, 1], :, :);
end
%value on gauss point
uhG = ValueGausspoint(uh);
uhGB = ValueGausspointB(uhB);
[Bxx, Byy] = ValueGausspointBedge(uhhB);

%integral on elements
FFF = zeros(N, N, 4, 4, dim2, 2);
parfor p = 1 : 4
    for q = 1 : 4
        FF = F(uhG(:, :, p, q, :), uhGB(:, :, p, q, :),0);
        FFF(:, :, p, q, :, :) = FF(:, :, :, :, 1 : 6, :);
    end
end


wwx = reshape(weight'*weight.*phix(:,:,1:dim1),[16,dim1]);
wwy = reshape(weight'*weight.*phiy(:,:,1:dim1),[16,dim1]);
F1_reshaped = reshape(FFF(:, :, :, :, :, 1),[N * N, 16, dim2]);
F2_reshaped = reshape(FFF(:, :, :, :, :, 2),[N * N, 16, dim2]);
duu = pagemtimes(F1_reshaped,wwx)+pagemtimes(F2_reshaped,wwy);
du = hh ^ 2 * reshape(duu, [N, N, dim1, dim2]) / hh;


uint = zeros(N, N, 1, 4, dim2);
uext = zeros(N, N, 1, 4, dim2);

uintB = zeros(N, N, 1, 4, 2);
uextB = zeros(N, N, 1, 4, 2);

FFFint = zeros(N, N, 4, dim2, 2);
FFFBint = zeros(N, N, 4, 2, 2);

FFFext = zeros(N, N, 4, dim2, 2);
FFFBext = zeros(N, N, 4, 2, 2);

uh_reshaped = reshape(uh,N*N,dim1,dim2);
uint_reshaped = pagemtimes(uh_reshaped,permute(phiU(:,1:dim1),[2 1]));
uint = reshape(uint_reshaped,[N,N,1,4,dim2]);

uhh_reshaped = reshape(uhh(3:end,2:end-1,:,:),N*N,dim1,dim2);
uext_reshaped = pagemtimes(uhh_reshaped,permute(phiD(:,1:dim1),[2 1]));
uext = reshape(uext_reshaped,[N,N,1,4,dim2]);


%top
uintB(:,:,1,:,1) = reshape(Bxx(2:end-1,2:end-1,:,1),[N, N, 1, 4, 1]);
uintB(:,:,1,:,2) = reshape(Byy(2:end-1,2:end-1,:,1),[N, N, 1, 4, 1]);
%bottom
uextB(:,:,1,:,1) = reshape(Bxx(3:end,2:end-1,:,2),[N, N, 1, 4, 1]);
uextB(:,:,1,:,2) = reshape(Byy(3:end,2:end-1,:,2),[N, N, 1, 4, 1]);

parfor p=1:4
    %F2
    FF=F(uint(:,:,1,p,:),uintB(:,:,1,p,:),2);
    FFFint(:,:,p,:,:)=FF(:,:,:,:,1:6,:);

    FF=F(uext(:,:,1,p,:),uextB(:,:,1,p,:),2);
    FFFext(:,:,p,:,:)=FF(:,:,:,:,1:6,:);

end

temp = zeros(N, N);
for p=1:4
    [~,alphay]=Alpha(uint(:,:,1,p,:),uintB(:,:,1,p,:),N,1);
    [~,alphayy]=Alpha(uext(:,:,1,p,:),uextB(:,:,1,p,:),N,1);
    temp=max(alphay,temp);
    temp=max(alphayy,temp);
end

wp = weight'.*phiU(:,1:dim1);
temp_reshaped = reshape(temp, N * N ,1);
F2int = reshape(FFFint(:, :, :, :, 2), [N * N, 4, dim2]);
F2ext = reshape(FFFext(:, :, :, :, 2), [N * N, 4, dim2]);
uint_reshaped = reshape(uint(:, :, :, :, :), [N * N, 4, dim2]);
uext_reshaped = reshape(uext(:, :, :, :, :), [N * N, 4, dim2]);

duu = -1/2*hh*pagemtimes((F2int+F2ext-temp_reshaped.*(uext_reshaped-uint_reshaped)),wp);
du = du + reshape(duu,[N,N,dim1,dim2]);

uint=zeros(N,N,1,4,dim2);
uext=zeros(N,N,1,4,dim2);

uintB=zeros(N,N,1,4,2);
uextB=zeros(N,N,1,4,2);

FFFint=zeros(N,N,4,dim2,2);
FFFBint=zeros(N,N,4,2,2);

FFFext=zeros(N,N,4,dim2,2);
FFFBext=zeros(N,N,4,2,2);



uint_reshaped = pagemtimes(uh_reshaped,permute(phiD(:,1:dim1),[2 1]));
uint = reshape(uint_reshaped,[N,N,1,4,dim2]);

uhh_reshaped = reshape(uhh(1:end-2,2:end-1,:,:),N*N,dim1,dim2);
uext_reshaped = pagemtimes(uhh_reshaped,permute(phiU(:,1:dim1),[2 1]));
uext = reshape(uext_reshaped,[N,N,1,4,dim2]);


%bottom
uintB(:,:,1,:,1) = reshape(Bxx(2:end-1,2:end-1,:,2),[N, N, 1, 4, 1]);
uintB(:,:,1,:,2) = reshape(Byy(2:end-1,2:end-1,:,2),[N, N, 1, 4, 1]);
%top
uextB(:,:,1,:,1) = reshape(Bxx(1:end-2,2:end-1,:,1),[N, N, 1, 4, 1]);
uextB(:,:,1,:,2) = reshape(Byy(1:end-2,2:end-1,:,1),[N, N, 1, 4, 1]);



parfor p=1:4
    %F2
    FF=F(uint(:,:,1,p,:),uintB(:,:,1,p,:),2);
    FFFint(:,:,p,:,:)=FF(:,:,:,:,1:6,:);

    FF=F(uext(:,:,1,p,:),uextB(:,:,1,p,:),2);
    FFFext(:,:,p,:,:)=FF(:,:,:,:,1:6,:);
end
temp=zeros(N,N);
for p=1:4
    [~,alphay]=Alpha(uint(:,:,1,p,:),uintB(:,:,1,p,:),N,1);
    [~,alphayy]=Alpha(uext(:,:,1,p,:),uextB(:,:,1,p,:),N,1);
    temp=max(temp,alphay);
    temp=max(temp,alphayy);
end

wp = weight'.*phiD(:,1:dim1);
temp_reshaped = reshape(temp, N * N ,1);
F2int = reshape(FFFint(:, :, :, :, 2), [N * N, 4, dim2]);
F2ext = reshape(FFFext(:, :, :, :, 2), [N * N, 4, dim2]);
uint_reshaped = reshape(uint(:, :, :, :, :), [N * N, 4, dim2]);
uext_reshaped = reshape(uext(:, :, :, :, :), [N * N, 4, dim2]);

duu = -1/2*hh*pagemtimes((-F2int-F2ext-temp_reshaped.*(uext_reshaped-uint_reshaped)),wp);
du = du + reshape(duu,[N,N,dim1,dim2]);


uint=zeros(N,N,1,4,dim2);
uext=zeros(N,N,1,4,dim2);

uintB=zeros(N,N,1,4,2);
uextB=zeros(N,N,1,4,2);

FFFint=zeros(N,N,4,dim2,2);
FFFBint=zeros(N,N,4,2,2);

FFFext=zeros(N,N,4,dim2,2);
FFFBext=zeros(N,N,4,2,2);


uint_reshaped = pagemtimes(uh_reshaped,permute(phiL(:,1:dim1),[2 1]));
uint = reshape(uint_reshaped,[N,N,1,4,dim2]);

uhh_reshaped = reshape(uhh(2:end-1,1:end-2,:,:),N*N,dim1,dim2);
uext_reshaped = pagemtimes(uhh_reshaped,permute(phiR(:,1:dim1),[2 1]));
uext = reshape(uext_reshaped,[N,N,1,4,dim2]);

%left
uintB(:,:,1,:,1) = reshape(Bxx(2:end-1,2:end-1,:,3),[N, N, 1, 4, 1]);
uintB(:,:,1,:,2) = reshape(Byy(2:end-1,2:end-1,:,3),[N, N, 1, 4, 1]);
%right
uextB(:,:,1,:,1) = reshape(Bxx(2:end-1,1:end-2,:,4),[N, N, 1, 4, 1]);
uextB(:,:,1,:,2) = reshape(Byy(2:end-1,1:end-2,:,4),[N, N, 1, 4, 1]);



parfor p=1:4
    FF=F(uint(:,:,1,p,:),uintB(:,:,1,p,:),1);
    FFFint(:,:,p,:,:)=FF(:,:,:,:,1:6,:);

    FF=F(uext(:,:,1,p,:),uextB(:,:,1,p,:),1);
    FFFext(:,:,p,:,:)=FF(:,:,:,:,1:6,:);

end
temp=zeros(N,N);
for p=1:4
    [alphax,~]=Alpha(uint(:,:,1,p,:),uintB(:,:,1,p,:),N,1);
    [alphaxx,~]=Alpha(uext(:,:,1,p,:),uextB(:,:,1,p,:),N,1);
    temp=max(temp,alphax);
    temp=max(temp,alphaxx);
end

wp = weight'.*phiL(:,1:dim1);
temp_reshaped = reshape(temp, N * N ,1);
F1int = reshape(FFFint(:, :, :, :, 1), [N * N, 4, dim2]);
F1ext = reshape(FFFext(:, :, :, :, 1), [N * N, 4, dim2]);
uint_reshaped = reshape(uint(:, :, :, :, :), [N * N, 4, dim2]);
uext_reshaped = reshape(uext(:, :, :, :, :), [N * N, 4, dim2]);

duu = -1/2*hh*pagemtimes((-F1int-F1ext-temp_reshaped.*(uext_reshaped-uint_reshaped)),wp);
du = du + reshape(duu,[N,N,dim1,dim2]);

uint=zeros(N,N,1,4,dim2);
uext=zeros(N,N,1,4,dim2);

uintB=zeros(N,N,1,4,2);
uextB=zeros(N,N,1,4,2);

FFFint=zeros(N,N,4,dim2,2);
%FFFBint=zeros(N,N,4,2,2);

FFFext=zeros(N,N,4,dim2,2);
%FFFBext=zeros(N,N,4,2,2);


uint_reshaped = pagemtimes(uh_reshaped,permute(phiR(:,1:dim1),[2 1]));
uint = reshape(uint_reshaped,[N,N,1,4,dim2]);

uhh_reshaped = reshape(uhh(2:end-1,3:end,:,:),N*N,dim1,dim2);
uext_reshaped = pagemtimes(uhh_reshaped,permute(phiL(:,1:dim1),[2 1]));
uext = reshape(uext_reshaped,[N,N,1,4,dim2]);

%right
uintB(:,:,1,:,1) = reshape(Bxx(2:end-1,2:end-1,:,4),[N, N, 1, 4, 1]);
uintB(:,:,1,:,2) = reshape(Byy(2:end-1,2:end-1,:,4),[N, N, 1, 4, 1]);
%left
uextB(:,:,1,:,1) = reshape(Bxx(2:end-1,3:end,:,3),[N, N, 1, 4, 1]);
uextB(:,:,1,:,2) = reshape(Byy(2:end-1,3:end,:,3),[N, N, 1, 4, 1]);


parfor p=1:4
    %F2
    FF=F(uint(:,:,1,p,:),uintB(:,:,1,p,:),1);
    FFFint(:,:,p,:,:)=FF(:,:,:,:,1:6,:);
    %FFFBint(:,:,p,:,:)=FF(:,:,:,:,7:8,:);


    FF=F(uext(:,:,1,p,:),uextB(:,:,1,p,:),1);
    FFFext(:,:,p,:,:)=FF(:,:,:,:,1:6,:);
    %FFFBext(:,:,p,:,:)=FF(:,:,:,:,7:8,:);
end
temp=zeros(N,N);
for p=1:4
    [alphax,~]=Alpha(uint(:,:,1,p,:),uintB(:,:,1,p,:),N,1);
    [alphaxx,~]=Alpha(uext(:,:,1,p,:),uextB(:,:,1,p,:),N,1);
    temp=max(temp,alphax);
    temp=max(temp,alphaxx);
end



wp = weight'.*phiR(:,1:dim1);
temp_reshaped = reshape(temp, N * N ,1);
F1int = reshape(FFFint(:, :, :, :, 1), [N * N, 4, dim2]);
F1ext = reshape(FFFext(:, :, :, :, 1), [N * N, 4, dim2]);
uint_reshaped = reshape(uint(:, :, :, :, :), [N * N, 4, dim2]);
uext_reshaped = reshape(uext(:, :, :, :, :), [N * N, 4, dim2]);

duu = -1/2*hh*pagemtimes((F1int+F1ext-temp_reshaped.*(uext_reshaped-uint_reshaped)),wp);
du = du + reshape(duu,[N,N,dim1,dim2]);


for i = 1 : dim1
    du(:, :, i, :) = du(:, :, i, :) / m(i);
end
du = du / hh ^ 2;
