function uhG = ValueGausspoint1D(uh)
%global phi1d
GaussQuadratureset;
[Nx, Ny, dim1] = size(uh);
uhG=zeros(Nx,Ny,4);


uh_reshape = reshape(uh, [Nx * Ny, dim1]);
%phi1d_reshape = reshape(phi1d(:, 1 : dim1), [4, dim1]);
%uhG_reshape = uh_reshape * phi1d_reshape';
uhG_reshape = uh_reshape * phi1d(:,1:dim1)';
uhG = reshape(uhG_reshape, [Nx, Ny, 4]);
% 
% 上面的有问题
% for i = 1:Nx
%     for j = 1 : Ny
%         for p = 1 : 4
%             for k = 1:dim1
% 
%                 uhG(i, j, p) = uhG(i, j, p) + uh(i, j, k) * phi1d(p, k);
%             end
%         end
%     end
% end

% % 将 uh reshape 成 [N*N, dim1] 的矩阵
% uh_reshaped = reshape(uh, [Nx*Ny, dim1]);
% 
% % 将 phi reshape 成 [4, dim1] 的矩阵（16 = 4*4）
% phi1d_reshaped = reshape(phi1d(:,1:dim1), [4, dim1]);
% 
% % 计算乘积并求和（使用矩阵乘法）
% uhG_reshaped = uh_reshaped*phi1d_reshaped';
% %uhG_reshaped = pagemtimes(uh_reshaped, permute(phi1d_reshaped, [2 1]));
% 
% % 将结果 reshape 回原始大小 [N, N, 4, 4, dim2]
% uhG = reshape(uhG_reshaped, [Nx, Ny, 4]);
end
