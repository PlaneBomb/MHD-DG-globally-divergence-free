function [dBxe, dBye] = LhB(uh, uhB, Bxe, Bye)
%solve the induction equation of magnetic field Bx By
%\partial_t b_x(y) + \partial_y E_z(x_{i+1/2},y) = 0
%\partial_t b_y(x) - \partial_x E_z(x,y_{j+1/2}) = 0
%E_z = u_yB_x - u_xB_y
global hh kp phi1dx phil1d phir1d weight m1
[Nx1, Ny1, ~] = size(Bxe);
[Nx2, Ny2, ~] = size(Bye);

%Ez_edgehorizon
%flux -Ez

%Ez_edgevertical
%flux Ez

[Ez_vertex, Ez_edgehorizon, Ez_edgevertical] = Ezflux(uh, uhB, Bxe, Bye);

%%
%solve b_x vertical
% phir1d = reshape(phir1d(1 : kp + 1), [1, 1, kp + 1]);
% phil1d = reshape(phil1d(1 : kp + 1), [1, 1, kp + 1]);
dBxe = zeros(size(Bxe));
%Nx1 = N
%Ny1 = N + 1

for k = 1 : kp + 1
    dBxe(:, :, k) = - (Ez_vertex(2 : end, :) * phir1d(k) - Ez_vertex(1 : end - 1, :) * phil1d(k));
end

for p = 1 : 4
    for k = 1 : kp + 1
        dBxe(:, :, k) = dBxe(:, :, k) - weight(p) * Ez_edgevertical(:, :, p) * phi1dx(p, k);
    end
end


%solve b_y horizon
dBye = zeros(size(Bye));


for k = 1: kp + 1
    dBye(:, :, k) = - (- Ez_vertex(:, 2 : end) * phir1d(k) + Ez_vertex(:, 1 : end - 1) * phil1d(k));
end
for p = 1 : 4
    for k = 1 : kp + 1
        dBye(:, :, k) = dBye(:, :, k) - weight(p) * Ez_edgehorizon(:, :, p) * phi1dx(p, k);
    end
end

for i = 1 : kp + 1
    dBxe(:, :, i) = dBxe(:, :, i) / m1(i);
    dBye(:, :, i) = dBye(:, :, i) / m1(i);
end
dBxe = dBxe / hh;
dBye = dBye / hh;

end

