%By error on horizontal edges
Byeerror = zeros(N, N + 1, 4);
error = 0;

%uhGB=ValueGausspointB(uhB);
uhByG = ValueGausspoint1D(Bye);
for i = 1 : Byesize(1)
    for j = 1 : Byesize(2)
        xx = Xc_horizon(i, j);
        yy = Yc_horizon(i, j);
        for p = 1 : 4
            x1 = xx + hh * point(p) - tFinal;
            y1 = yy - tFinal;
            if prob == 4
                % x1 = xx + hh * point(p) - sqrt(2) / 2 * tFinal;
                % y1 = yy - sqrt(2) / 2 * tFinal;
                x1 = xx + hh * point(p);
                y1 = yy;
            end
            Byeerror(i, j, p) = abs(f8(x1, y1) - uhByG(i, j, p));
            error = error + weight(p) * Byeerror(i, j, p) ^ 2 * hh;
        end
    end
end
error = error / N;
disp(['Bye err = ' num2str(sqrt(error))]);