function f = minmod(a, b, c)

f = min(abs(a), abs(b));
f = min(f, abs(c));

f = sign(a) .* f .* (sign(a) == sign(b) & sign(a) == sign(c));

    % if sign(a)==sign(b) && sign(b)==sign(c)
    %     s=sign(a);
    %     f=s*min(abs([a,b,c]));
    % else
    %     f=0;
    % end

end

