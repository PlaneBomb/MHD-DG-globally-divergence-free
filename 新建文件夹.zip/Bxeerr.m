%Bx error on  vertical edges
Bxeerror = zeros(N + 1, N, 4);
error = 0;

%uhGB=ValueGausspointB(uhB);
uhBxG = ValueGausspoint1D(Bxe);
for i = 1 : Bxesize(1)
    for j = 1 : Bxesize(2)
        xx = Xc_vertical(i, j);
        yy = Yc_vertical(i, j);
        for p = 1 : 4
            x1 = xx - tFinal;
            y1 = yy + hh * point(p) - tFinal;
            if prob == 4
                % x1 = xx - sqrt(2) / 2 * tFinal;
                % y1 =  yy + hh * point(p) - sqrt(2) / 2 * tFinal;
                x1 = xx;
                y1 = yy + hh * point(p);
            end
            Bxeerror(i, j, p) = abs(f7(x1, y1) - uhBxG(i, j, p));
            error = error + weight(p) * Bxeerror(i, j, p) ^ 2 * hh;
        end
    end
end
error = error / N;
disp(['Bxe err = ' num2str(sqrt(error))]);