function [Bxe, Bye] = Magneticfield2edge(uhB)
[Nx, Ny, ~, ~] = size(uhB);
global kp

Bxe = zeros(Nx, Ny + 1, kp + 1);
Bye = zeros(Nx + 1, Ny ,kp + 1);


if kp == 1
    Bxe(:, 1 : end - 1, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1);
    Bxe(:, 1 : end - 1, 2) = uhB(:, :, 3, 1) - uhB(:, :, 5, 1);

    Bxe(:, end, 1) = uhB(:, end, 1, 1) + uhB(:, end, 2, 1) + 2 / 3 * uhB(:, end, 4, 1);
    Bxe(:, end, 2) = uhB(:, end, 3, 1) + uhB(:, end, 5, 1);

    Bye(1 : end - 1, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 5, 2);
    Bye(1 : end - 1, :, 2) = uhB(:, :, 2, 2) - uhB(:, :, 4, 2);

    Bye(end, :, 1) = uhB(end, :, 1, 2) + uhB(end, :, 3, 2) + 2 / 3 * uhB(end, :, 5, 2);
    Bye(end, :, 2) = uhB(end, :, 2, 2) + uhB(end, :, 4, 2);
end

if kp == 2

    Bxe(:, 1 : end - 1, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + 2 / 3 * uhB(:, :, 4, 1) - 2 / 5 * uhB(:, :, 7, 1);
    Bxe(:, 1 : end - 1, 2) = uhB(:, :, 3, 1) - uhB(:, :, 5, 1);
    Bxe(:, 1 : end - 1, 3) = uhB(:, :, 6, 1) - uhB(:, :, 8, 1);

    Bxe(:, end, 1) = uhB(:, end, 1, 1) + uhB(:, end, 2, 1) + 2 / 3 * uhB(:, end, 4, 1);
    Bxe(:, end, 2) = uhB(:, end, 3, 1) + uhB(:, end, 5, 1);
    Bxe(:, end, 3) = uhB(:, end, 6, 1) + uhB(:, end, 8, 1);

    Bye(1 : end - 1, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 6, 2) - 2 / 5 * uhB(:, :, 8, 2);
    Bye(1 : end - 1, :, 2) = uhB(:, :, 2, 2) - uhB(:, :, 5, 2);
    Bye(1 : end - 1, :, 3) = uhB(:, :, 4, 2) - uhB(:, :, 7, 2);

    Bye(end, :, 1) = uhB(end, :, 1, 2) + uhB(end, :, 3, 2) + 2 / 3 * uhB(end, :, 5, 2);
    Bye(end, :, 2) = uhB(end, :, 2, 2) + uhB(end, :, 4, 2);
    Bye(end, :, 3) = uhB(end, :, 4, 2) + uhB(end, :, 7, 2);
end
end

