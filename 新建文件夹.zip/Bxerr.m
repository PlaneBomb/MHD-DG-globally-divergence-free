%Bx err in elements

Bxerror = zeros(N, N, 4, 4);
error = 0;
uhGB = ValueGausspointB(uhB);
for i=1:N
    for j=1:N
        for p=1:4
            for q=1:4
                x0 = hh*point(p)+Xmid(i,j);
                y0 = hh*point(q)+Ymid(i,j);

                x1 = x0 - tFinal;
                y1 = y0 - tFinal;
                if prob == 4
                    % x1 = x0 - sqrt(2) / 2 * tFinal;
                    % y1 = y0 - sqrt(2) / 2 * tFinal;
                    x1 = x0;
                    y1 = y0;
                end
                Bxerror(i, j, p, q) = abs(f7(x1, y1) - uhGB(i, j, p, q, 1));
                %Bxerror(i, j, p, q) = abs(f7(x1, y1) - uhGBx(i, j, p, q));
                error = error + weight(p) * weight(q) * Bxerror(i, j, p, q) ^ 2 * hh ^ 2;
            end
        end
    end
end
disp(sqrt(error));
% disp(['Bx err = ' num2str(sqrt(error))]);