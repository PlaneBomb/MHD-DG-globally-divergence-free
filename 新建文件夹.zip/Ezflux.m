function [Ez_vertex, Ez_edgehorizon, Ez_edgevertical] = Ezflux(uh, uhB, Bxe, Bye)
global kp bc phiD phiU phiL phiR phiBD phiBU phiBL phiBR
gamma =5/3;
%GaussQuadratureset;
%uhB = MagneticFieldReconstruction(uh, Bxe, Bye);
[N, ~, dim1, dim2] = size(uh);
[~, ~, dimB, ~] = size(uhB);
[Nx1, Ny1, ~] = size(Bxe);
[Nx2, Ny2, ~] = size(Bye);

uhh = zeros(N + 2, N + 2, dim1, dim2);
uhhB = zeros(N + 2, N + 2, dimB, 2);

if strcmp(bc, 'period')

    uhh(2 : end - 1, 2 : end - 1, :, :) = uh;
    uhhB(2 : end - 1, 2 : end - 1, :, :) = uhB;

    uhh([1, end], 2 : end - 1, :, :) = uh([end, 1], :, :, :);
    uhh(2 : end - 1, [1, end], :, :) = uh(:, [end, 1], :, :);

    uhhB([1, end], 2 : end - 1, :, :) = uhB([end, 1], :, :, :);
    uhhB(2 : end - 1, [1, end], :, :) = uhB(:, [end, 1], :, :);

end
%%
%compute all flux at vertices
%Ez:value on each element's vertices ordered by LU, RU, RD, LD
%Ez_vertex values on each vertex
Ez_element = zeros(N, N, 4);
Uy = zeros(N, N, 4);
Ux = zeros(N, N, 4);
Bx = zeros(N, N, 4);
By = zeros(N, N, 4);
rho = zeros(N, N, 4);
E = zeros(N, N, 4);
if kp == 1
    %P1
    %LU (-1, 1)
    rho(:, :, 1) = uh(:, :, 1, 1) - uh(:, :, 2, 1) + uh(:, :, 3, 1);
    Ux(:, :, 1) = (uh(:, :, 1, 2) - uh(:, :, 2, 2) + uh(:, :, 3, 2)) ./ rho(:, :, 1);
    Uy(:, :, 1) = (uh(:, :, 1, 3) - uh(:, :, 2, 3) + uh(:, :, 3, 3)) ./ rho(:, :, 1);
    Bx(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) - uhB(:, :, 5, 1);
    By(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2) + uhB(:, :, 3, 2) - uhB(:, :, 4, 2) + 2 / 3 * uhB(:, :, 5, 2);
    %E(:, :, 1) = uh(:, :, 1, 6) - uh(:, :, 2, 6) + uh(:, :, 3, 6);
    %RU (1, 1)
    rho(:, :, 2) = uh(:, :, 1, 1) + uh(:, :, 2, 1) + uh(:, :, 3, 1);
    Ux(:, :, 2) = (uh(:, :, 1, 2) + uh(:, :, 2, 2) + uh(:, :, 3, 2)) ./ rho(:, :, 2);
    Uy(:, :, 2) = (uh(:, :, 1, 3) + uh(:, :, 2, 3) + uh(:, :, 3, 3)) ./ rho(:, :, 2);
    Bx(:, :, 2) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) + uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) + uhB(:, :, 5, 1);
    By(:, :, 2) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2) + uhB(:, :, 3, 2) + uhB(:, :, 4, 2) + 2 / 3 * uhB(:, :, 5, 2);
    %E(:, :, 2) = uh(:, :, 1, 6) + uh(:, :, 2, 6) + uh(:, :, 3, 6);
    %RD (1, -1)
    rho(:, :, 3) = uh(:, :, 1, 1) + uh(:, :, 2, 1) - uh(:, :, 3, 1);
    Ux(:, :, 3) = (uh(:, :, 1, 2) + uh(:, :, 2, 2) - uh(:, :, 3, 2)) ./ rho(:, :, 3);
    Uy(:, :, 3) = (uh(:, :, 1, 3) + uh(:, :, 2, 3) - uh(:, :, 3, 3)) ./ rho(:, :, 3);
    Bx(:, :, 3) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) - uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) - uhB(:, :, 5, 1);
    By(:, :, 3) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2) - uhB(:, :, 3, 2) - uhB(:, :, 4, 2) + 2 / 3 * uhB(:, :, 5, 2);
    %E(:, :, 3) = uh(:, :, 1, 6) + uh(:, :, 2, 6) - uh(:, :, 3, 6);
    %LD (-1, -1)
    rho(:, :, 4) = uh(:, :, 1, 1) - uh(:, :, 2, 1) - uh(:, :, 3, 1);
    Ux(:, :, 4) = (uh(:, :, 1, 2) - uh(:, :, 2, 2) - uh(:, :, 3, 2)) ./ rho(:, :, 4);
    Uy(:, :, 4) = (uh(:, :, 1, 3) - uh(:, :, 2, 3) - uh(:, :, 3, 3)) ./ rho(:, :, 4);
    Bx(:, :, 4) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) - uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) + uhB(:, :, 5, 1);
    By(:, :, 4) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2) - uhB(:, :, 3, 2) + uhB(:, :, 4, 2) + 2 / 3 * uhB(:, :, 5, 2);
    %E(:, :, 4) = uh(:, :, 1, 6) - uh(:, :, 2, 6) - uh(:, :, 3, 6);
end

if kp == 2
    %P2
    %LU (-1,1)
    rho(:, :, 1) = uh(:, :, 1, 1) - uh(:, :, 2, 1) + uh(:, :, 3, 1) ...
        + 2 / 3 * uh(:, :, 4, 1) - uh(:, :, 5, 1) + 2 / 3 * uh(:, :, 6, 1);

    Ux(:, :, 1) = (uh(:, :, 1, 2) - uh(:, :, 2, 2) + uh(:, :, 3, 2)...
        + 2 / 3 * uh(:, :, 4, 2) - uh(:, :, 5, 2) + 2 / 3 * uh(:, :, 6, 2)) ./ rho(:, :, 1);

    Uy(:, :, 1) = (uh(:, :, 1, 3) - uh(:, :, 2, 3) + uh(:, :, 3, 3)...
        + 2 / 3 * uh(:, :, 4, 3) - uh(:, :, 5, 3) + 2 / 3 * uh(:, :, 6, 3)) ./ rho(:, :, 1);

    Bx(:, :, 1) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) + uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) - uhB(:, :, 5, 1)...
        + 2 / 3 * uhB(:, :, 6, 1) - 2 / 5 * uhB(:, :, 7, 1) - 2 / 3 * uhB(:, :, 8, 1);

    By(:, :, 1) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2) + uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 4, 2) - uhB(:, :, 5, 2)...
        + 2 / 3 * uhB(:, :, 6, 2) + 2 / 3 * uhB(:, :, 7, 2) + 2 / 5 * uhB(:, :, 8, 2);
    E(:, :, 1) = uh(:, :, 1, 6) - uh(:, :, 2, 6) + uh(:, :, 3, 6) ...
        + 2 / 3 * uh(:, :, 4, 6) - uh(:, :, 5, 6) + 2 / 3 * uh(:, :, 6, 6);
    %RU (1,1)
    rho(:, :, 2) = uh(:, :, 1, 1) + uh(:, :, 2, 1) + uh(:, :, 3, 1) ...
        + 2 / 3 * uh(:, :, 4, 1) + uh(:, :, 5, 1) + 2 / 3 * uh(:, :, 6, 1);

    Ux(:, :, 2) = (uh(:, :, 1, 2) + uh(:, :, 2, 2) + uh(:, :, 3, 2)...
        + 2 / 3 * uh(:, :, 4, 2) + uh(:, :, 5, 2) + 2 / 3 * uh(:, :, 6, 2)) ./ rho(:, :, 2);

    Uy(:, :, 2) = (uh(:, :, 1, 3) + uh(:, :, 2, 3) + uh(:, :, 3, 3)...
        + 2 / 3 * uh(:, :, 4, 3) + uh(:, :, 5, 3) + 2 / 3 * uh(:, :, 6, 3)) ./ rho(:, :, 2);

    Bx(:, :, 2) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) + uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) + uhB(:, :, 5, 1)...
        + 2 / 3 * uhB(:, :, 6, 1) + 2 / 5 * uhB(:, :, 7, 1) + 2 / 3 * uhB(:, :, 8, 1);

    By(:, :, 2) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2) + uhB(:, :, 3, 2) +  2 / 3 * uhB(:, :, 4, 2) + uhB(:, :, 5, 2)...
        + 2 / 3 * uhB(:, :, 6, 2) + 2 / 3 * uhB(:, :, 7, 2) + 2 / 5 * uhB(:, :, 8, 2);
        E(:, :, 2) = uh(:, :, 1, 6) + uh(:, :, 2, 6) + uh(:, :, 3, 6) ...
        + 2 / 3 * uh(:, :, 4, 6) + uh(:, :, 5, 6) + 2 / 3 * uh(:, :, 6, 6);
    %RD (1,-1)
    rho(:, :, 3) = uh(:, :, 1, 1) + uh(:, :, 2, 1) - uh(:, :, 3, 1) ...
        + 2 / 3 * uh(:, :, 4, 1) - uh(:, :, 5, 1) + 2 / 3 * uh(:, :, 6, 1);

    Ux(:, :, 3) = (uh(:, :, 1, 2) + uh(:, :, 2, 2) - uh(:, :, 3, 2) ...
        + 2 / 3 * uh(:, :, 4, 2) - uh(:, :, 5, 2) + 2 / 3 * uh(:, :, 6, 2)) ./ rho(:, :, 3);

    Uy(:, :, 3) = (uh(:, :, 1, 3) + uh(:, :, 2, 3) - uh(:, :, 3, 3) ...
        + 2 / 3 * uh(:, :, 4, 3) - uh(:, :, 5, 3) + 2 / 3 * uh(:, :, 6, 3)) ./ rho(:, :, 3);

    Bx(:, :, 3) = uhB(:, :, 1, 1) + uhB(:, :, 2, 1) - uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) - uhB(:, :, 5, 1)...
        + 2 / 3 * uhB(:, :, 6, 1) + 2 / 5 * uhB(:, :, 7, 1) + 2 / 3 * uhB(:, :, 8, 1);

    By(:, :, 3) = uhB(:, :, 1, 2) + uhB(:, :, 2, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 4, 2) - uhB(:, :, 5, 2)...
        + 2 / 3 * uhB(:, :, 6, 2) - 2 / 3 * uhB(:, :, 7, 2) - 2 / 5 * uhB(:, :, 8, 2);

        E(:, :, 3) = uh(:, :, 1, 6) + uh(:, :, 2, 6) - uh(:, :, 3, 6) ...
        + 2 / 3 * uh(:, :, 4, 6) - uh(:, :, 5, 6) + 2 / 3 * uh(:, :, 6, 6);
    %LD(-1,-1)
    rho(:, :, 4) = uh(:, :, 1, 1) - uh(:, :, 2, 1) - uh(:, :, 3, 1) ...
        + 2 / 3 * uh(:, :, 4, 1) + uh(:, :, 5, 1) + 2 / 3 * uh(:, :, 6, 1);

    Ux(:, :, 4) = (uh(:, :, 1, 2) - uh(:, :, 2, 2) - uh(:, :, 3, 2) ...
        + 2 / 3 * uh(:, :, 4, 2) + uh(:, :, 5, 2) + 2 / 3 * uh(:, :, 6, 2)) ./ rho(:, :, 4);

    Uy(:, :, 4) = (uh(:, :, 1, 3) - uh(:, :, 2, 3) - uh(:, :, 3, 3) ...
        + 2 / 3 * uh(:, :, 4, 3) + uh(:, :, 5, 3) + 2 / 3 * uh(:, :, 6, 3)) ./ rho(:, :, 4);
    Bx(:, :, 4) = uhB(:, :, 1, 1) - uhB(:, :, 2, 1) - uhB(:, :, 3, 1) + 2 / 3 * uhB(:, :, 4, 1) + uhB(:, :, 5, 1)...
        + 2 / 3 * uhB(:, :, 6, 1) - 2 / 5 * uhB(:, :, 7, 1) - 2 / 3 * uhB(:, :, 8, 1);

    By(:, :, 4) = uhB(:, :, 1, 2) - uhB(:, :, 2, 2) - uhB(:, :, 3, 2) + 2 / 3 * uhB(:, :, 4, 2) + uhB(:, :, 5, 2)...
        + 2 / 3 * uhB(:, :, 6, 2) - 2 / 3 * uhB(:, :, 7, 2) - 2 / 5 * uhB(:, :, 8, 2);
    E(:, :, 4) = uh(:, :, 1, 6) - uh(:, :, 2, 6) - uh(:, :, 3, 6) ...
        + 2 / 3 * uh(:, :, 4, 6) + uh(:, :, 5, 6) + 2 / 3 * uh(:, :, 6, 6);
end

%%
%eigen speed
% uhG = ValueGausspoint(uh);
% uhGB = ValueGausspointB(uhB);

% for i = 1 : 4
%     alpha1 = abs(Ux(:, :, i));
%     beta1 = abs(Uy(:, :, i));
%     alpha = max(alpha1, alpha);
%     beta = max(beta1, beta);
% end


for i = 1 : 4
    Ez_element(:, :, i) = Uy(:, :, i) .* Bx(:, :, i) - Ux(:, :, i) .* By(:, :, i);
end
%%
Ez_elementt = zeros(N + 2, N + 2, 4);
Bxx = zeros(N + 2, N + 2, 4);
Byy = zeros(N + 2, N + 2, 4);
Uxx = zeros(N + 2, N + 2, 4);
Uyy = zeros(N + 2, N + 2, 4);
Ee = zeros(N + 2, N + 2, 4);

rhoo  = zeros(N + 2, N + 2, 4);
if strcmp(bc, 'period')
    Ez_elementt(2 : end - 1, 2 : end - 1, :) = Ez_element;
    Ez_elementt([1, end], 2 : end - 1, :) = Ez_element([end, 1], :, :);
    Ez_elementt(2 : end - 1, [1, end], :) = Ez_element(:, [end, 1], :);
    Ez_elementt([1, end], [1, end], :) = Ez_element([end, 1], [end, 1], :);

    Bxx(2 : end - 1, 2 : end - 1, :) = Bx;
    Bxx([1, end], 2 : end - 1, :) = Bx([end, 1], :, :);
    Bxx(2 : end - 1, [1, end], :) = Bx(:, [end, 1], :);
    Bxx([1, end], [1, end], :) = Bx([end, 1], [end, 1], :);


    Byy(2 : end - 1, 2 : end - 1, :) = By;
    Byy([1, end], 2 : end - 1, :) = By([end, 1], :, :);
    Byy(2 : end - 1, [1, end], :) = By(:, [end, 1], :);
    Byy([1, end], [1, end], :) = By([end, 1], [end, 1], :);

    Uxx(2 : end - 1, 2 : end - 1, :) = Ux;
    Uxx([1, end], 2 : end - 1, :) = Ux([end, 1], :, :);
    Uxx(2 : end - 1, [1, end], :) = Ux(:, [end, 1], :);
    Uxx([1, end], [1, end], :) = Ux([end, 1], [end, 1], :);


    Uyy(2 : end - 1, 2 : end - 1, :) = Uy;
    Uyy([1, end], 2 : end - 1, :) = Uy([end, 1], :, :);
    Uyy(2 : end - 1, [1, end], :) = Uy(:, [end, 1], :);
    Uyy([1, end], [1, end], :) = Uy([end, 1], [end, 1], :);

    Ee(2 : end - 1, 2 : end - 1, :) = E;
    Ee([1, end], 2 : end - 1, :) = E([end, 1], :, :);
    Ee(2 : end - 1, [1, end], :) = E(:, [end, 1], :);
    Ee([1, end], [1, end], :) = E([end, 1], [end, 1], :);

    rhoo(2 : end - 1, 2 : end - 1, :) = rho;
    rhoo([1, end], 2 : end - 1, :) = rho([end, 1], :, :);
    rhoo(2 : end - 1, [1, end], :) = rho(:, [end, 1], :);
    rhoo([1, end], [1, end], :) = rho([end, 1], [end, 1], :);
end

% cfx = zeros(size(Bxx));
% cfy = zeros(size(Bxx));
% for i = 1 : 4
%     Bnorm = Bxx(:, :, i) .^ 2 + Byy(:, :, i) .^ 2;
%     pre = (gamma - 1) * (Ee(:, :, i) - 0.5 * (Uxx(:, :, i) .^ 2 + Uyy(:, :, i) .^ 2) .* rhoo(:, :, i) - 0.5 * Bnorm);
%     a = sqrt(gamma * pre ./ rhoo(:, :, i));
% 
%     cfx(:,:,i) = sqrt(0.5*(a .^ 2 + Bnorm ./ rhoo(:, :, i) + sqrt((a .^ 2 + Bnorm ./ rhoo(:, :, i)) .^ 2 - 4 * a .^ 2 .* Bxx(:,:,i) .^ 2 ./ rhoo(:, :, i))));
%     cfy(:,:,i) = sqrt(0.5*(a .^ 2 + Bnorm ./ rhoo(:, :, i) + sqrt((a .^ 2 + Bnorm ./ rhoo(:, :, i)) .^ 2 - 4 * a .^ 2 .* Byy(:,:,i) .^ 2 ./ rhoo(:, :, i))));
% end
alpha= zeros(N + 1, N + 1);
beta= zeros(N + 1, N + 1);
% for i = 1 : N + 1
%     for j = 1 : N + 1
%         alpha(i, j) = max(abs([Uxx(i, j, 2) + cfx(i, j, 2), Uxx(i, j + 1, 1) + cfx(i, j + 1, 1), Uxx(i + 1, j, 3)+cfx(i + 1, j, 3), Uxx(i + 1, j + 1, 4)+cfx(i + 1, j + 1, 4)]));
%         beta(i, j) = max(abs([Uyy(i, j, 2) + cfy(i, j, 2), Uyy(i, j + 1, 1)+ cfy(i, j + 1, 1), Uyy(i + 1, j, 3)+cfy(i + 1, j, 3), Uyy(i + 1, j + 1, 4)+cfy(i + 1, j + 1, 4)]));
%     end
% end
for i = 1 : N + 1
    for j = 1 : N + 1
        alpha(i, j) = max(abs([Uxx(i, j, 2), Uxx(i, j + 1, 1), Uxx(i + 1, j, 3), Uxx(i + 1, j + 1, 4)]));
        beta(i, j) = max(abs([Uyy(i, j, 2), Uyy(i, j + 1, 1), Uyy(i + 1, j, 3), Uyy(i + 1, j + 1, 4)]));
    end
end


% alpha = max(abs([reshape(Uxx(1 : end - 1, 1 : end - 1, 2), (N + 1) * (N + 1), 1)'; ...
%     reshape(Uxx(1 : end - 1, 2 : end, 1), (N + 1) * (N + 1), 1)'; ...
%     reshape(Uxx(2 : end, 1 : end - 1, 3), (N + 1) * (N + 1), 1)'; ...
%     reshape(Uxx(2 : end, 2 : end, 4), (N + 1) * (N + 1), 1)']));
% alpha = reshape(alpha', N + 1, N + 1)';
% beta = max(abs([reshape(Uyy(1 : end - 1, 1 : end - 1, 2), (N + 1) * (N + 1), 1)' ; ...
%     reshape(Uyy(1 : end - 1, 2 : end, 1), (N + 1) * (N + 1), 1)'; ...
%     reshape(Uyy(2 : end, 1 : end - 1, 3), (N + 1) * (N + 1), 1)'; ...
%     reshape(Uyy(2 : end, 2 : end, 4), (N + 1) * (N + 1), 1)']));
% beta = reshape(beta', N + 1, N + 1)';

%
%global LF
% alpha = max(max(alpha));
% beta = max(max(beta));
%%
%at point P
%EZ LU RU LD RD
%   3  4 + 2  1
%Bx
%   3  4 - 2  1
%By RD RU LD LU
%   1  4 - 2  3

%1.2 hll
%1 average of one dimension LF
%用2.0 multidimension LF

Ez_vertex = 1 / 4 * (Ez_elementt(1 : end - 1, 1 : end - 1, 2) + Ez_elementt(1 : end - 1, 2 : end, 1) ...
    + Ez_elementt(2 : end, 1 : end - 1, 3) + Ez_elementt(2 : end, 2 : end, 4)) ...
    - 2.0 * beta / 4 .* ((Bxx(2 : end, 1 : end - 1, 3) + Bxx(2 : end, 2 : end, 4)) / 2 - ...
    (Bxx(1 : end - 1, 1 : end - 1, 2) + Bxx(1 : end - 1, 2 : end, 1)) / 2) ...
    + 2.0 * alpha / 4 .* ((Byy(1 : end - 1, 2 : end, 1) + Byy(2 : end, 2 : end, 4)) / 2 - ...
    (Byy(1 : end - 1, 1 : end - 1, 2) + Byy(2 : end, 1 : end - 1, 3)) / 2);

%%
%Ez_edge flux at gauss quadrature points(1d)
%x direction (horizon)
% = (Ez_LD + Ez_LU)/2-beta/2*(B_xLU-B_xLD)
%Ez_edgehorizon = zeros(Nx2, Ny2, 4);
[Bx1, By1] = ValueGausspointBedge(uhB);
Bx11 = zeros(N+2,N+2,4,4);
By11 = zeros(N+2,N+2,4,4);
if strcmp(bc, 'period')
    Bx11(2 : end - 1, 2 : end - 1, :,:) = Bx1;
    Bx11([1, end], 2 : end - 1,  :,:) = Bx1([end, 1], :,  :,:);
    Bx11(2 : end - 1, [1, end], :,:) = Bx1(:, [end, 1],  :,:);
    Bx11([1, end], [1, end], :,:) = Bx1([end, 1], [end, 1],  :,:);

    By11(2 : end - 1, 2 : end - 1,  :,:) = By1;
    By11([1, end], 2 : end - 1,  :,:) = By1([end, 1], :,  :,:);
    By11(2 : end - 1, [1, end],  :,:) = By1(:, [end, 1],  :,:);
    By11([1, end], [1, end],  :,:) = By1([end, 1], [end, 1],  :,:);
end
if kp == 1
    %LU
    phiBxD = phiD(:, 1 : 5);
    phiByD = phiD(:, [1 : 3, 5 : 6]);

    phiBxU = phiU(:, 1 : 5);
    phiByU = phiU(:, [1 : 3, 5 : 6]);
else
    %LU
    phiBxD = [phiD(:, :), phiBD(:, 1 : 2)];
    phiByD = [phiD(:, :), phiBD(:, 3 : 4)];
    phiBxU = [phiU(:, :), phiBU(:, 1 : 2)];
    phiByU = [phiU(:, :), phiBU(:, 3 : 4)];
end
%LU


rho = reshape(uhh(2 : end, 2 : end - 1, :, 1), [Nx2 * Ny2, dim1]) * phiD(:, 1 : dim1)';
rhoux = reshape(uhh(2 : end, 2 : end - 1, :, 2), [Nx2 * Ny2, dim1]) * phiD(:, 1 : dim1)';
rhouy = reshape(uhh(2 : end, 2 : end - 1, :, 3), [Nx2 * Ny2, dim1]) * phiD(:, 1 : dim1)';

% BxedgeU = reshape(uhhB(2 : end, 2 : end - 1, :, 1), [Nx2 * Ny2, dimB]) * phiBxD(:, :)';
% Byedge = reshape(uhhB(2 : end, 2 : end - 1, :, 2), [Nx2 * Ny2, dimB]) * phiByD(:, :)';

BxedgeU = reshape(Bx11(2:end,2:end-1,:,2), [Nx2 * Ny2, 4]);
Byedge = reshape(By11(2:end,2:end-1,:,2), [Nx2 * Ny2, 4]);
Ez_horizonU = rhouy ./ rho .* BxedgeU - rhoux ./ rho .* Byedge;
%Ez_edgehorizon = Ez_horizonU / 2 - beta / 2 .* Bx;
beta1 = abs(rhouy ./ rho);
%LD

rho = reshape(uhh(1 : end - 1, 2 : end - 1, :, 1), [Nx2 * Ny2, dim1]) * phiU(:, 1 : dim1)';
rhoux = reshape(uhh(1 : end - 1, 2 : end - 1, :, 2), [Nx2 * Ny2, dim1]) * phiU(:, 1 : dim1)';
rhouy = reshape(uhh(1 : end - 1, 2 : end - 1, :, 3), [Nx2 * Ny2, dim1]) * phiU(:, 1 : dim1)';

% BxedgeD = reshape(uhhB(1 : end - 1, 2 : end - 1, :, 1), [Nx2 * Ny2, dimB]) * phiBxU(:, :)';
% Byedge = reshape(uhhB(1 : end - 1, 2 : end - 1, :, 2), [Nx2 * Ny2, dimB]) * phiByU(:, :)';

BxedgeD = reshape(Bx11(1 : end - 1, 2 : end - 1,:,1), [Nx2 * Ny2, 4]);
Byedge = reshape(By11(1 : end - 1, 2 : end - 1,:,1), [Nx2 * Ny2, 4]);
Ez_horizonD = rhouy ./ rho .* BxedgeD - rhoux ./ rho .* Byedge;
beta2 = abs(rhouy ./ rho);
beta = zeros(Nx2 * Ny2, 4);
for i = 1 : 4
    beta(:, i) = max(beta1(:, i), beta2(:, i));
end
Ez_edgehorizon = Ez_horizonU / 2  + Ez_horizonD / 2 - beta / 2 .* (BxedgeU - BxedgeD);
Ez_edgehorizon = reshape(Ez_edgehorizon, [Nx2, Ny2, 4]);




%%
%y direction (vertical)
% -Ez=(-Ez_RD - Ez_LD)/2-alpha/2*(B_yRD-B_yLD)

if kp == 1
    %RD  (x_{i+1/2},y)
    phiBxL = phiL(:, 1 : 5);
    phiByL = phiL(:, [1 : 3, 5 : 6]);
    phiBxR = phiR(:, 1 : 5);
    phiByR = phiR(:, [1 : 3, 5 : 6]);
else
    phiBxL = [phiL(:, :), phiBL(:, 1 : 2)];
    phiByL = [phiL(:, :), phiBL(:, 3 : 4)];
    phiBxR = [phiR(:, :), phiBR(:, 1 : 2)];
    phiByR = [phiR(:, :), phiBR(:, 3 : 4)];
end

%RD
rho = reshape(uhh(2 : end - 1, 2 : end, :, 1), [Nx1 * Ny1, dim1]) * phiL(:, 1 : dim1)';
rhoux = reshape(uhh(2 : end - 1, 2 : end, :, 2), [Nx1 * Ny1, dim1]) * phiL(:, 1 : dim1)';
rhouy = reshape(uhh(2 : end - 1, 2 : end, :, 3), [Nx1 * Ny1, dim1]) * phiL(:, 1 : dim1)';

% Bxedge = reshape(uhhB(2 : end - 1, 2 : end, :, 1), [Nx1 * Ny1, dimB]) * phiBxL(:, :)';
% ByedgeR = reshape(uhhB(2 : end - 1, 2 : end, :, 2), [Nx1 * Ny1, dimB]) * phiByL(:, :)';

%这里的Bxedge会导致出负 修改ValueGausspointBedg后好了
Bxedge = reshape(Bx11(2 : end - 1, 2 : end, :,3), [Nx1 * Ny1, 4]);
ByedgeR = reshape(By11(2 : end - 1, 2 : end, :,3), [Nx1 * Ny1, 4]);

Ez_verticalR = rhouy ./ rho .* Bxedge - rhoux ./ rho .* ByedgeR;
%Ez_edgevertical = - Ez_verticalR / 2 - alpha / 2 * By;
alpha1 = abs(rhoux ./ rho);
%LD

rho = reshape(uhh(2 : end - 1, 1 : end - 1, :, 1), [Nx1 * Ny1, dim1]) * phiR(:, 1 : dim1)';
rhoux = reshape(uhh(2 : end - 1, 1 : end - 1, :, 2), [Nx1 * Ny1, dim1]) * phiR(:, 1 : dim1)';
rhouy = reshape(uhh(2 : end - 1, 1 : end - 1, :, 3), [Nx1 * Ny1, dim1]) * phiR(:, 1:dim1)';

% Bxedge = reshape(uhhB(2 : end - 1, 1 : end - 1, :, 1), [Nx1 * Ny1, dimB]) * phiBxR(:, :)';
% ByedgeL = reshape(uhhB(2 : end - 1, 1 : end - 1, :, 2), [Nx1 * Ny1, dimB]) * phiByR(:, :)';

Bxedge = reshape(Bx11(2 : end - 1, 1 : end - 1, :, 4), [Nx1 * Ny1, 4]);
ByedgeL = reshape(By11(2 : end - 1, 1 : end - 1, :, 4), [Nx1 * Ny1, 4]);

Ez_verticalL = rhouy ./ rho .* Bxedge - rhoux ./ rho .* ByedgeL;

alpha2 = abs(rhouy ./ rho);

alpha = zeros(Nx1 * Ny1, 4);
for i = 1 : 4
    alpha(:, i) = max(alpha1(:, i), alpha2(:, i));
end
Ez_edgevertical = - Ez_verticalR / 2  - Ez_verticalL / 2  - alpha / 2 .* (ByedgeR - ByedgeL);
Ez_edgevertical = reshape(Ez_edgevertical, [Nx1, Ny1, 4]);


end



