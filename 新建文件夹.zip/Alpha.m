function [alphax,alphay]=Alpha(uhG,uhGB,N,quad)
%global gamma
gamma = 5 / 3;

%%41s
alphax = zeros(N, N);
alphay = zeros(N, N);
for p = 1 : quad
    for q = 1 : quad
        u = uhG(:, :, p, q, :);
        uB = uhGB(:, :, p, q, :);
        Bnorm = uB(:, :, 1) .^ 2 + uB(:, :, 2) .^ 2 + u(:, :, 5) .^ 2;
        pre = (gamma - 1) * (u(:, :, 6) - 0.5 * (u(:, :, 2) .^ 2 + u(:, :, 3) .^ 2 + u(:, :, 4) .^ 2) ./ u(:, :, 1) - 0.5 * Bnorm);
        a = sqrt(gamma * pre ./ u(:, :, 1));
        rho = u(:, :, 1);
        %Bnorm=sum(uB.^2);
        Bx = uB(:, :, 1);
        By = uB(:, :, 2);

        cfx = sqrt(0.5*(a .^ 2 + Bnorm ./ rho + sqrt((a .^ 2 + Bnorm ./ rho) .^ 2 - 4 * a .^ 2 .* Bx .^ 2 ./ rho)));
        cfy = sqrt(0.5*(a .^ 2 + Bnorm ./ rho + sqrt((a .^ 2 + Bnorm ./ rho) .^ 2 - 4 * a .^ 2 .* By .^ 2 ./ rho)));

        alphax1 = abs(u(:, : ,2) ./ u(:, :, 1)) + cfx;
        alphay1 = abs(u(:, :, 3) ./ u(:, :, 1)) + cfy;
        % alphax1 = abs(u(:, : ,2) ./ u(:, :, 1));
        % alphay1 = abs(u(:, :, 3) ./ u(:, :, 1));
        alphax = max(alphax, alphax1);
        alphay = max(alphay, alphay1);
    end
end

end