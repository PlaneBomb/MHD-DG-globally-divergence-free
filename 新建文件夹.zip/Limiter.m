function uhmod = Limiter(uh)

% TVD or TVB components-wise
global bc hh prob limiterind kp
eps = 1e-7;
[N, ~, dim1, dim2] = size(uh);
%dim1 # basis func
%dim2 # variables

uave = uh(:, :, 1, :);
uhh = zeros(N + 2, N + 2, 1, dim2);

uhh(2 : end - 1, 2 : end - 1, :, :) = uave;
%period bc
uhh([1, end], 2 : end - 1, :, :) = uave([end, 1], :, :, :);
uhh(2 : end - 1, [1, end], :, :) = uave(:, [end, 1], :, :);


urave = uhh(2 : end - 1, 3 : end, 1, :);
ulave = uhh(2 : end - 1, 1 : end - 2, 1, :);

uuave = uhh(3 : end, 2 : end - 1, 1, :);
udave = uhh(1 : end - 2, 2 : end - 1, 1, :);
if prob == 4
    M = 4*sqrt(2);
else
    M=4;
end
if strcmp(bc, 'period') && limiterind ~= 0
    uh_reshape = reshape(uh, [N * N, dim1, dim2]);
    uave = uh(:, :, 1, :);

    %不用minmod 光滑解好

    % urave = circshift(uave,[0,-1]);
    % ulave = circshift(uave,[0,1]);
    % uuave = circshift(uave,[1,0]);
    % udave = circshift(uave,[-1,0]);


    uave_reshape = reshape(uave, [N * N, 1, dim2]);
    ulave_reshape = reshape(ulave, [N * N, 1, dim2]);
    urave_reshape = reshape(urave, [N * N, 1, dim2]);
    uuave_reshape = reshape(uuave, [N * N, 1, dim2]);
    udave_reshape = reshape(udave, [N * N, 1, dim2]);


    %tvd minmod
    if limiterind == 1
        uhmodx=arrayfun(@(a, b, c) minmod(a, b, c),uh_reshape(:,2,:),urave_reshape-uave_reshape,uave_reshape-ulave_reshape);
        uhmody=arrayfun(@(a, b, c) minmod(a, b, c),uh_reshape(:,3,:),uuave_reshape-uave_reshape,uave_reshape-udave_reshape);
    end


    % tvb minmod
    if limiterind == 2
        uhmodx = arrayfun(@(a,b,c,d,e) minmod2(a,b,c,d,e), uh_reshape(:,2,:), urave_reshape - uave_reshape, uave_reshape-ulave_reshape,M*ones(size(uave_reshape)),hh*ones(size(uave_reshape)));
        uhmody = arrayfun(@(a,b,c,d,e) minmod2(a,b,c,d,e), uh_reshape(:,3,:), uuave_reshape - uave_reshape, uave_reshape-udave_reshape,M*ones(size(uave_reshape)),hh*ones(size(uave_reshape)));
    end


    isModifiedx = [];
    isModifiedy = [];
    for k = 1 : dim2
        isModifiedx1 = find(abs(uhmodx(:, 1, k) - uh_reshape(:, 2, k))>=eps);

        isModifiedx = union(isModifiedx, isModifiedx1);

        isModifiedy1 = find(abs(uhmody(:, 1, k) - uh_reshape(:, 3, k))>=eps);
        isModifiedy = union(isModifiedy, isModifiedy1);
    end

    %disp(isModifiedx);
    isModified = union(isModifiedx,isModifiedy);

    uh_reshape(isModified, 2, :) = uhmodx(isModified, 1, :);
    uh_reshape(isModified, 3, :) = uhmody(isModified, 1, :);
    if kp >= 2
        uh_reshape(isModified, 4 : end, :) = 0;
    end

    % uhB_reshape = reshape(uhB,[N*N,9,1]);
    % uhB_reshape(isModified, 6 : 9, :) = 0;
    uh = reshape(uh_reshape, [N, N, dim1, dim2]);
    % uhB = reshape(uhB_reshape,[N,N,9,1]);
end
uhmod=uh;
% uhBmod = uhB;
end

