function uhGB = ValueGausspointB(uhB)
global kp phiB phi
%GaussQuadratureset;
[Nx, Ny, dim1, dim2] = size(uhB);
uhGB = zeros(Nx, Ny, 4, 4, 2);
%uhb = zeros(Nx, Ny, dim1 + 1, 2);

if kp == 1
    %dim1 = 5
    %Bx = a0+a1 x+a2 y+ a3 (x^2 - 1/3) +a4 xy <- bx(y)
    %By = b0+b1 x+b2 y+ b3 xy +b4 (y^2 - 1/3) <- by(x)


    phii1 = zeros(4, 4, dim1);
    phii2 = zeros(4, 4, dim1);

    phii1(:, :, 1 : dim1 - 2) = phi(:, :, 1 : dim1 - 2);
    phii1(:, :, dim1 - 1 : dim1) = phi(:, :, 4 : 5);

    phii2(:, :, 1 : dim1 - 2) = phi(:, :, 1 : dim1 - 2);
    phii2(:, :, dim1 - 1 : dim1) = phi(:, :, 5 : 6);
elseif kp == 2
    phii1 = zeros(4, 4, dim1);
    phii2 = zeros(4, 4, dim1);

    phii1(:, :, 1 : dim1 - 2) = phi;
    phii1(:, :, dim1 - 1 : dim1) = phiB(:, :, 1 : 2);

    phii2(:, :, 1 : dim1 - 2) = phi;
    phii2(:, :, dim1 - 1 : dim1) = phiB(:, :, 3 : 4);
end

uhB1_reshaped = reshape(uhB(:, :, :, 1), [Nx * Ny, dim1, 1]);
phii1_reshaped = reshape(phii1, [16, dim1]);
uhGB1_reshaped = pagemtimes(uhB1_reshaped, permute(phii1_reshaped, [2 1]));

uhB2_reshaped = reshape(uhB(:, :, :, 2), [Nx*Ny, dim1, 1]);
phii2_reshaped = reshape(phii2, [16, dim1]);
uhGB2_reshaped = pagemtimes(uhB2_reshaped, permute(phii2_reshaped, [2 1]));

uhGB(:, :, :, :, 1) = reshape(uhGB1_reshaped, [Nx, Ny, 4, 4, 1]);
uhGB(:, :, :, :, 2) = reshape(uhGB2_reshaped, [Nx, Ny, 4, 4, 1]);

% if kp == 2
%     for p = 1 : 4
%         for q = 1 : 4
%             for k = 1 : dim1 - 2
%                 uhGB(:, :, p, q, 1) = uhGB(:, :, p, q, 1) + uhB(:, :, k, 1) * phi(p, q, k);
%                 uhGB(:, :, p, q, 2) = uhGB(:, :, p, q, 2) + uhB(:, :, k, 2) * phi(p, q, k);
%
%             end
%             for  k = dim1 - 1 : dim1
%                 uhGB(:, :, p, q, 1) =  uhGB(:, :, p, q, 1) + uhB(:, :, k, 1) * phiB(p, q, k - dim1 + 2);
%                 uhGB(:, :, p, q, 2) =  uhGB(:, :, p, q, 2) + uhB(:, :, k, 2) * phiB(p, q, k - dim1 + 4);
%             end
%         end
%
%     end
% end

% uhb(:, :, 1 : 5, 1) = uhB(:, :, 1 : 5, 1);
% uhb(:, :, [1 : 3, 5 : 6], 2) = uhB(:, :, 1 : 5, 2);
% uhGB = ValueGausspoint(uhb);
end



