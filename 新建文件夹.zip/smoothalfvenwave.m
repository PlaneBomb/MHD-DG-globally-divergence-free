gamma = 5 / 3;
p = @(x,y)  0.1;
betta = @(x, y) sqrt(2) / 2 * (x + y);
v1 = @(x,y) - sqrt(2) / 2 * 0.1 * sin(2*pi*betta(x, y));
v2 = @(x,y)  sqrt(2) / 2 * 0.1 * sin(2*pi*betta(x, y));
v3 = @(x,y) 0.1 * cos(2*pi*betta(x, y));
%rho
f1 = @(x, y) 1;

%rhoux
f2 = @(x, y) f1(x,y) .* v1(x,y);
%rhouy
f3 = @(x, y) f1(x,y) .* v2(x,y);
%rhouz
f4 = @(x, y) f1(x, y) .* v3(x, y);

%bz
f5 = @(x,y) v3(x, y);
%magnetic field
f7 = @(x,y) sqrt(2) / 2 - sqrt(2) / 2 * 0.1 * sin(2*pi*betta(x, y));
f8 = @(x,y) sqrt(2) / 2 + sqrt(2) / 2 * 0.1 * sin(2*pi*betta(x, y));

%energy
f6 = @(x, y) p(x, y) / (gamma - 1) + 0.5 * (f2(x, y) .^ 2 + f3(x, y) .^ 2 + f4(x, y) .^ 2) ./ f1(x, y)...
    + 0.5*(f5(x,y).^2 + f7(x,y).^2+f8(x,y).^2);

xa = 0; xb = sqrt(2);
ya = 0; yb = sqrt(2);