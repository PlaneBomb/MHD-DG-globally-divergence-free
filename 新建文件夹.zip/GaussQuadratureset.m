[point,weight]=fourpoint_Gauss();

%%
%Legendre basis 1D
%[-1,1]
phi11 = @(x) ones(size(x));
phi12 = @(x) x;
phi13 = @(x) x .^ 2 - 1 / 3;
phi14 = @(x) x.^3 - 3 / 5 * x;

m1 = [2, 2 / 3, 8 / 45];

phi11dx = @(x) zeros(size(x));
phi12dx = @(x) ones(size(x));
phi13dx = @(x) 2 .* x;

%points*3
phi1d = [phi11(point); phi12(point); phi13(point);phi14(point)]';
phi1dx = [phi11dx(point); phi12dx(point); phi13dx(point)]';

phir1d = [1, 1, 2 / 3];
phil1d = [1, -1, 2 / 3];

%Legendre basis 2D
%on [-1,1]*[-1,1]
%%P2
phi1 = @(x, y) ones(size(x));
phi2 = @(x, y) x;
phi3 = @(x, y) y;

phi4 = @(x, y) x .^ 2 - 1 / 3;
phi5 = @(x, y) x .* y;
phi6 = @(x, y) y .^ 2 - 1 / 3;


phi7 = @(x, y) x .^ 3 - 3 / 5 * x;
phi8 = @(x, y) x .* (y .^ 2 - 1 / 3);

phi9 = @(x, y) y .* (x .^ 2 - 1 / 3);
phi10 = @(x, y) y .^ 3 - 3 / 5 * y;
m=[4, 4/3, 4/3, 16/45, 4/9, 16/45];

phix1=@(x,y) 0.*x;
phix2=@(x,y) 1;
phix3=@(x,y) 0.*x;

phix4=@(x,y) 2*x;
phix5=@(x,y) y;
phix6=@(x,y) 0.*x;


phiy1=@(x,y) 0.*x;
phiy2=@(x,y) 0.*x;
phiy3=@(x,y) 1;

phiy4=@(x,y) 0.*y;
phiy5=@(x,y) x;
phiy6=@(x,y) 2*y;


phi=zeros(4,4,6);
phix=zeros(4,4,6);
phiy=zeros(4,4,6);

phiB = zeros(4, 4, 4);
phiBL = zeros(4, 4);
phiBR = zeros(4, 4);
phiBU = zeros(4, 4);
phiBD = zeros(4, 4);
for  i= 1:4
    for j = 1:4
        phiB(i,j,1)=phi7(point(i),point(j));
        phiB(i,j,2)=phi8(point(i),point(j));
        phiB(i,j,3)=phi9(point(i),point(j));
        phiB(i,j,4)=phi10(point(i),point(j));
    end
end

for j = 1 : 4
        phiBL(j,1)=phi7(-1,point(j));
        phiBL(j,2)=phi8(-1,point(j));
        phiBL(j,3)=phi9(-1,point(j));
        phiBL(j,4)=phi10(-1,point(j));
end
for j = 1 : 4
        phiBR(j,1)=phi7(1,point(j));
        phiBR(j,2)=phi8(1,point(j));
        phiBR(j,3)=phi9(1,point(j));
        phiBR(j,4)=phi10(1,point(j));
end
for j = 1 : 4
        phiBU(j,1)=phi7(point(j),1);
        phiBU(j,2)=phi8(point(j),1);
        phiBU(j,3)=phi9(point(j),1);
        phiBU(j,4)=phi10(point(j),1);
end
for j = 1 : 4
        phiBD(j,1)=phi7(point(j),-1);
        phiBD(j,2)=phi8(point(j),-1);
        phiBD(j,3)=phi9(point(j),-1);
        phiBD(j,4)=phi10(point(j),-1);
end
for i=1:4
    for j=1:4
        phi(i,j,1)=phi1(point(i),point(j));
        phi(i,j,2)=phi2(point(i),point(j));
        phi(i,j,3)=phi3(point(i),point(j));
        phi(i,j,4)=phi4(point(i),point(j));
        phi(i,j,5)=phi5(point(i),point(j));
        phi(i,j,6)=phi6(point(i),point(j));

        phix(i,j,1)=phix1(point(i),point(j));
        phix(i,j,2)=phix2(point(i),point(j));
        phix(i,j,3)=phix3(point(i),point(j));
        phix(i,j,4)=phix4(point(i),point(j));
        phix(i,j,5)=phix5(point(i),point(j));
        phix(i,j,6)=phix6(point(i),point(j));

        phiy(i,j,1)=phiy1(point(i),point(j));
        phiy(i,j,2)=phiy2(point(i),point(j));
        phiy(i,j,3)=phiy3(point(i),point(j));
        phiy(i,j,4)=phiy4(point(i),point(j));
        phiy(i,j,5)=phiy5(point(i),point(j));
        phiy(i,j,6)=phiy6(point(i),point(j));
    end
end
%%
%%value on edge
%left (-1,point(q))
phiL=zeros(4,6);
for q=1:4
    phiL(q,1)=phi1(-1,point(q));
    phiL(q,2)=phi2(-1,point(q));
    phiL(q,3)=phi3(-1,point(q));
    phiL(q,4)=phi4(-1,point(q));
    phiL(q,5)=phi5(-1,point(q));
    phiL(q,6)=phi6(-1,point(q));
end

%right (1,point(p))
phiR=zeros(4,6);
for q=1:4
    phiR(q,1)=phi1(1,point(q));
    phiR(q,2)=phi2(1,point(q));
    phiR(q,3)=phi3(1,point(q));
    phiR(q,4)=phi4(1,point(q));
    phiR(q,5)=phi5(1,point(q));
    phiR(q,6)=phi6(1,point(q));
end

phiU=zeros(4,6);
for q=1:4
    phiU(q,1)=phi1(point(q),1);
    phiU(q,2)=phi2(point(q),1);
    phiU(q,3)=phi3(point(q),1);
    phiU(q,4)=phi4(point(q),1);
    phiU(q,5)=phi5(point(q),1);
    phiU(q,6)=phi6(point(q),1);
end

phiD=zeros(4,6);
for q=1:4
    phiD(q,1)=phi1(point(q),-1);
    phiD(q,2)=phi2(point(q),-1);
    phiD(q,3)=phi3(point(q),-1);
    phiD(q,4)=phi4(point(q),-1);
    phiD(q,5)=phi5(point(q),-1);
    phiD(q,6)=phi6(point(q),-1);
end