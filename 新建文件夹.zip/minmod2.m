function u=minmod2(a,b,c,M,h)


isTVB = (abs(a) <= M  * h.^2);
u = a .* isTVB;
u = u + minmod(a, b, c) .* ~isTVB;

    % if abs(a)<M*h.^2
    %     u=a;
    % else 
    %     u=minmod(a,b,c);
    % end
end