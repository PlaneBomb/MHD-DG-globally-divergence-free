gamma=5/3;

p = @(x, y)  1 - (x.^2 + y.^2)./(8*pi.^2)*exp(1 - x.^2 - y.^2);
v1 = @(x, y) 1 - 1./(2.*pi).*exp(0.5.*(1 - (x.^2 + y.^2))).*y;
v2 = @(x, y) 1 + 1./(2.*pi).*exp(0.5.*(1 - (x.^2 + y.^2))).*x;
v3 = @(x, y) 0;
%rho
f1 = @(x, y) 1 + 0 .* x;
%rhoux
f2 = @(x, y) f1(x, y) .* v1(x, y);
%rhouy
f3 = @(x, y) f1(x, y) .* v2(x, y);
%rhouz
f4 = @(x, y) f1(x, y) .* v3(x, y);
%magnetic field
%bz
f5 = @(x, y) 0;
%bx by
f7 = @(x,y) - 1./(2.*pi).*exp(0.5.*(1 - (x.^2 + y.^2))).*y;
f8 = @(x,y) 1./(2.*pi).*exp(0.5.*(1 - (x.^2 + y.^2))).*x;

%energy
f6 = @(x,y) p(x,y)/(gamma-1) + 0.5*(f2(x,y).^2 + f3(x,y).^2 + f4(x, y).^2)./f1(x,y) + 0.5*(f5(x,y).^2 + f7(x,y).^2 + f8(x, y).^2);

xa = -10; xb = 10;
ya = -10; yb = 10;