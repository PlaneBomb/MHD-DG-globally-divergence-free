function max_div = checkdivB(Bhar)
%CHECKDIVB Summary of this function goes here
%   Detailed explanation goes here
global hh
[N,~,~] = size(Bhar);
max_div = 0;
for i = 1 : N
    for j = 1 : N
        divB = Bhar(i, j, 3) / hh + Bhar(i, j, 6) / hh;
        max_div = max(divB, max_div);
    end
end

disp(max_div);
end

