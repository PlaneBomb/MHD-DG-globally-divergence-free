function uhG = ValueGausspoint(uh)
global phi kp
%GaussQuadratureset;
[Nx ,Ny, dim1, dim2] = size(uh);
%uhG=zeros(N,N,4,4,dim2);

% 将 uh reshape 成 [N*N, dim1, dim2] 的矩阵
uh_reshaped = reshape(uh, [Nx * Ny, dim1, dim2]);

% 将 phi reshape 成 [16, dim1] 的矩阵（16 = 4*4）
phi_reshaped = reshape(phi(:, :, 1 : dim1), [16, dim1]);

% 计算乘积并求和（使用矩阵乘法）
uhG_reshaped = pagemtimes(uh_reshaped, permute(phi_reshaped, [2 1]));

% 将结果 reshape 回原始大小 [N, N, 4, 4, dim2]
uhG = reshape(uhG_reshaped, [Nx, Ny, 4, 4, dim2]);
end
