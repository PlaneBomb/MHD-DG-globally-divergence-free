uerr = zeros(N, N, 4, 4);
error = 0;
uhG = ValueGausspoint(uh);
for i = 1 : N
    for j = 1 : N
        for p = 1 : 4
            for q = 1 : 4
                x0 = hh * point(p) + Xmid(i, j);
                y0 = hh * point(q) + Ymid(i, j);

                x1 = x0 - tFinal;
                y1 = y0 - tFinal;
                if prob == 4
                    % x1 = x0 - sqrt(2) / 2 * tFinal;
                    % y1 = y0 - sqrt(2) / 2 * tFinal;
                    x1 = x0;
                    y1 = y0;
                end
                %uerr(i,j,p,q)=abs(f5(x1,y1)-uhGB(i,j,p,q,1));
                uerr(i, j, p, q) = abs(f1(x1, y1) - uhG(i, j, p, q, 1));
                error = error + weight(p) * weight(q) * uerr(i, j, p, q) ^ 2 * hh ^ 2;
            end
        end
    end
end
disp(sqrt(error));
%disp(['density err = ' num2str(sqrt(error))]);