function  [uhGBdx, uhGBdy] = DerivateValueGausspointB(uhB)
global kp point hh
%GaussQuadratureset;
[Nx, Ny, dim1, dim2] = size(uhB);
uhGB = zeros(Nx, Ny, 4, 4, 2);

uhGBdx = zeros(Nx, Ny, 4, 4, 2);
uhGBdy = zeros(Nx, Ny, 4, 4, 2);

if kp == 1
    %Bx = a0+a1 x+a2 y+ a3 (x^2 - 1/3) +a4 xy <- bx(y)
    %By = b0+b1 x+b2 y+ b3 xy +b4 (y^2 - 1/3) <- by(x)

    for p = 1 : 4
        for q = 1 : 4
            uhGBdx(:, :, p, q, 1) = uhB(:, :, 2, 1) + 2 * uhB(:, :, 4, 1) * point(p) + uhB(:, :, 5, 1) * point(q);
            uhGBdy(:, :, p, q, 2) = uhB(:, :, 3, 2) + uhB(:, :, 4, 2) * point(p) + 2 * uhB(:, :, 5, 2) * point(q);
        end
    end
end


if kp == 2
    %reconsturcion

    for p = 1 : 4
        for q = 1 : 4
            uhGBdx(:, :, p, q, 1) = uhB(:, :, 2, 1) + 2 * uhB(:, :, 4, 1) * point(p) + uhB(:, :, 5, 1) * point(q) +...
                uhB(:, :, 7, 1) * (3 * point(p) ^2 - 3 / 5) + uhB(:, :, 8, 1) * (point(q) ^ 2 - 1 / 3);
            uhGBdy(:, :, p, q, 2) = uhB(:, :, 3, 2) + uhB(:, :, 5, 2) * point(p) + 2 * uhB(:, :, 6, 2) * point(q) +...
                uhB(:, :, 7, 2) * (point(p) ^ 2 - 1 / 3) + uhB(:, :, 8, 2) * (3 * point(q) ^ 2 - 3 / 5);
        end
    end


end

uhGBdx = uhGBdx / hh;
uhGBdy = uhGBdy / hh;